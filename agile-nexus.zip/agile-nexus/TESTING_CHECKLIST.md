# Manual Testing Checklist

## Pre-Testing Setup
- [ ] PostgreSQL running
- [ ] Virtual environment activated
- [ ] All dependencies installed
- [ ] Database tables created

## API Endpoint Testing

### Basic Endpoints
- [ ] GET / - Returns API status
- [ ] GET /api-status - Returns system health
- [ ] GET /health-check - Returns healthy status

### Data Pipeline
- [ ] GET /run-etl - Extracts data successfully
- [ ] GET /run-processing - Processes data successfully
- [ ] Check database has data after ETL

### ML Models - Individual Tests
- [ ] GET /test-sprint-model - Trains and predicts
- [ ] GET /test-productivity-model - Trains and predicts
- [ ] GET /test-dependency-model - Trains and predicts
- [ ] Verify predictions are within valid ranges

### ML Models - Training
- [ ] GET /train-all-models - All 3 models train
- [ ] Check model files saved in data/ folder
- [ ] Training completes in < 10 seconds

### ML Models - Predictions
- [ ] GET /predict-sprint-risk - Returns risk scores
- [ ] GET /predict-productivity - Returns productivity scores
- [ ] GET /analyze-dependencies - Returns dependency analysis
- [ ] Predictions consistent across multiple calls

### Full Pipeline
- [ ] GET /run-full-pipeline - Complete flow works
- [ ] All components execute in sequence
- [ ] Results include all model outputs

## Dashboard Testing

### Login
- [ ] Can login as Team Leader (leader/leader123)
- [ ] Can login as Team Member (member/member123)
- [ ] Invalid credentials show error

### Data Loading
- [ ] "Load Sprint Data" button works
- [ ] "Load Productivity" button works
- [ ] "Load Dependencies" button works
- [ ] Data displays correctly in UI

### Role-Based Access
- [ ] Team Leader can train models
- [ ] Team Member cannot train models
- [ ] Buttons disabled for Team Member

### Visual Elements
- [ ] Risk scores display correctly
- [ ] Color coding works (green/yellow/red)
- [ ] Statistics update when data loads
- [ ] Dashboard responsive to different screen sizes

## Performance Testing

### Response Times
- [ ] API responses < 500ms
- [ ] Model training < 10 seconds
- [ ] Dashboard loads < 2 seconds
- [ ] ETL processing < 15 seconds

### Data Volume
- [ ] Can handle 100+ calendar events
- [ ] Can handle 50+ dependencies
- [ ] Database queries remain fast

## Error Handling

### API Errors
- [ ] Invalid endpoints return 404
- [ ] Server errors return 500 with message
- [ ] Missing data handled gracefully

### Model Errors
- [ ] Training with no data shows error
- [ ] Prediction before training shows error
- [ ] Invalid input data handled

## Browser Compatibility
- [ ] Chrome - All features work
- [ ] Firefox - All features work
- [ ] Edge - All features work
- [ ] Safari - All features work (if Mac available)

## Test Results Summary

Date Tested: ___________
Tester: ___________
Total Tests: ___________
Passed: ___________
Failed: ___________

Notes:
_________________________________
_________________________________