from etl_pipeline.slack_real import SlackRealExtractor
from dotenv import load_dotenv
import os
load_dotenv()
# Get token from environment
slack_token = os.getenv('SLACK_BOT_TOKEN')

if not slack_token:
    print("❌ SLACK_BOT_TOKEN not found in environment!")
    print("Make sure .env file has: SLACK_BOT_TOKEN=xoxb-...")
    exit(1)

print("\n" + "="*60)
print("Testing Slack API Connection")
print("="*60)

try:
    extractor = SlackRealExtractor(slack_token)
    print("✅ Slack connection successful!")
    
    # Extract team activity
    print("\nExtracting team activity (last 7 days)...")
    activity = extractor.extract_team_activity(days_back=7)
    
    print(f"\n✅ Found {len(activity)} team members\n")
    
    for member in activity:
        print(f"👤 {member['real_name']} ({member['user_name']})")
        print(f"   Messages: {member['message_count']}")
        print(f"   Active Hours: {member['active_hours']}")
        print(f"   Avg Response: {member['response_time_avg']} min")
        print()
        
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()