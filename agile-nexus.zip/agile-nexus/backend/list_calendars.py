from etl_pipeline.google_calendar_real import GoogleCalendarRealExtractor

try:
    extractor = GoogleCalendarRealExtractor()
    
    print("\n" + "="*60)
    print("Your Google Calendars")
    print("="*60)
    
    calendars = extractor.get_user_calendars()
    
    print(f"\nTotal calendars: {len(calendars)}\n")
    
    for i, cal in enumerate(calendars, 1):
        print(f"{i}. {cal['summary']}")
        print(f"   ID: {cal['id']}")
        print(f"   Primary: {cal['primary']}")
        print()
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()