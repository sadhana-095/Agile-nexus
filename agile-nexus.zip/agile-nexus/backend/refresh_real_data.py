"""
Refresh all real data (delete old, extract new)
"""
from app import create_app
from models import db, CalendarData, CommunicationData, CodeActivity
from etl_pipeline.real_api_coordinator import RealAPICoordinator

app = create_app()

with app.app_context():
    print("\n" + "="*60)
    print("REFRESHING REAL DATA")
    print("="*60)
    
    # Step 1: Delete old real data
    print("\n1️⃣ Deleting old real data...")
    
    cal_deleted = CalendarData.query.filter_by(data_source='real').delete()
    print(f"   Deleted {cal_deleted} calendar events")
    
    comm_deleted = CommunicationData.query.filter_by(data_source='real').delete()
    print(f"   Deleted {comm_deleted} communication records")
    
    code_deleted = CodeActivity.query.filter_by(data_source='real').delete()
    print(f"   Deleted {code_deleted} code activity records")
    
    db.session.commit()
    
    # Step 2: Extract fresh data
    print("\n2️⃣ Extracting fresh data...")
    
    coordinator = RealAPICoordinator()
    github_users = ['Rooba8925', 'praneetaAD078','sadhana-095']  # Add all teammates
    
    results = coordinator.run_real_extraction(
        days_back=365,  # Get 1 year of data
        github_usernames=github_users
    )
    
    # Step 3: Show results
    print("\n3️⃣ Results:")
    print(f"   Calendar: {results['calendar']} events")
    print(f"   Communication: {results['communication']} records")
    print(f"   Code: {results['code']} records")
    
    # Step 4: Verify database
    print("\n4️⃣ Database verification:")
    
    real_cal = CalendarData.query.filter_by(data_source='real').count()
    real_comm = CommunicationData.query.filter_by(data_source='real').count()
    real_code = CodeActivity.query.filter_by(data_source='real').count()
    
    print(f"   Calendar: {real_cal} events")
    print(f"   Communication: {real_comm} records")
    print(f"   Code: {real_code} records")
    
    print("\n✅ Refresh complete!")
    print("="*60)