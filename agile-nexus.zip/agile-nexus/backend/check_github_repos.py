from etl_pipeline.github_real import GitHubRealExtractor
from dotenv import load_dotenv
import os
load_dotenv()
from github import Github

github_token = os.getenv('GITHUB_TOKEN')

if not github_token:
    print("❌ GITHUB_TOKEN not found!")
    exit(1)

print("\n" + "="*60)
print("Checking Your GitHub Repositories")
print("="*60)

try:
    g = Github(github_token)
    user = g.get_user()
    
    print(f"\n✅ Connected as: {user.login}")
    print(f"Name: {user.name}")
    print(f"Email: {user.email}\n")
    
    repos = list(user.get_repos())
    
    print(f"Total repositories: {len(repos)}\n")
    
    if len(repos) == 0:
        print("❌ No repositories found!")
        print("\nPossible reasons:")
        print("1. Token doesn't have 'repo' permission")
        print("2. Account has no repositories")
        print("3. Using wrong GitHub account")
    else:
        print("Your repositories:\n")
        for repo in repos:
            print(f"📦 {repo.name}")
            print(f"   Full Name: {repo.full_name}")
            print(f"   Private: {repo.private}")
            print(f"   Fork: {repo.fork}")
            print(f"   URL: {repo.html_url}")
            print()
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()