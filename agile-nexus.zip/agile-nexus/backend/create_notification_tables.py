"""
Create notification and alert tables
"""

from app import create_app
from models import db

app = create_app()

with app.app_context():
    print("\n" + "="*70)
    print("CREATING NOTIFICATION TABLES")
    print("="*70)
    
    try:
        db.create_all()
        print("\n✅ Notification tables created successfully!")
        print("   - notifications")
        print("   - risk_alerts")
        print("\n" + "="*70)
        
    except Exception as e:
        print(f"\n❌ Error: {e}")