"""
Verify complete system
"""
from app import create_app
from models import db, User, CalendarData, CodeActivity, CommunicationData

app = create_app()

with app.app_context():
    print("\n" + "="*70)
    print("AGILE NEXUS SYSTEM VERIFICATION")
    print("="*70)
    
    # Check Users
    print("\n👥 USERS:")
    users = User.query.all()
    for user in users:
        print(f"   {user.full_name} (@{user.username}) - Role: {user.role}")
    
    # Check Data
    print("\n📊 DATA SUMMARY:")
    print(f"   Calendar Events: {CalendarData.query.count()}")
    print(f"   Slack Messages: {CommunicationData.query.count()}")
    print(f"   GitHub Repos: {CodeActivity.query.count()}")
    
    print("\n✅ System Ready!")
    print("="*70)