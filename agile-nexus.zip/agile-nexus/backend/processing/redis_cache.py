import redis
import json
from datetime import timedelta
import logging

logger = logging.getLogger(__name__)

class RedisCache:
    """Redis cache manager for fast data access"""
    
    def __init__(self, host='localhost', port=6379, db=0):
        try:
            self.redis_client = redis.Redis(
                host=host,
                port=port,
                db=db,
                decode_responses=True
            )
            self.redis_client.ping()
            logger.info("✅ Redis connected")
        except Exception as e:
            logger.warning(f"⚠️ Redis not available: {e}")
            self.redis_client = None
    
    def set_cache(self, key, value, expiry_seconds=1800):
        """Cache data with expiry (default 30 minutes)"""
        try:
            if self.redis_client:
                self.redis_client.setex(
                    key,
                    timedelta(seconds=expiry_seconds),
                    json.dumps(value)
                )
                return True
        except Exception as e:
            logger.error(f"Cache set failed: {e}")
        return False
    
    def get_cache(self, key):
        """Get cached data"""
        try:
            if self.redis_client:
                value = self.redis_client.get(key)
                if value:
                    return json.loads(value)
        except Exception as e:
            logger.error(f"Cache get failed: {e}")
        return None
    
    def cache_sprint_predictions(self, predictions):
        """Cache sprint predictions for 15 minutes"""
        return self.set_cache('sprint_predictions:latest', predictions, 900)
    
    def get_sprint_predictions(self):
        """Get cached sprint predictions"""
        return self.get_cache('sprint_predictions:latest')
    
    def cache_heatmap(self, heatmap_data):
        """Cache productivity heatmap for 30 minutes"""
        return self.set_cache('productivity_heatmap:latest', heatmap_data, 1800)
    
    def get_heatmap(self):
        """Get cached heatmap"""
        return self.get_cache('productivity_heatmap:latest')