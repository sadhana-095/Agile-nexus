# processing/user_mapping.py

"""
User ID normalization mapping
Maps all user identifiers (Slack IDs, emails, GitHub usernames) to standardized usernames
"""

USER_MAPPING = {
    # Slack IDs -> Standard Username
    'U091IAKATDK': 'praneetaad078',
    'U091IAQH9PF': 'rooba8925',
    'U09L8AWBSH2': 'sadhana-095',
    
    # Calendar Emails -> Standard Username
    'praneetadevesh26@gmail.com': 'praneetaad078',
    'roobabaskaran194@gmail.com': 'rooba8925',
    'sadhanaraja7651@gmail.com': 'sadhana-095',
    'classroom100805441420632441831@group.calendar.google.com': 'team_calendar',
    'classroom116521636338140189060@group.calendar.google.com': 'team_calendar',
    
    # GitHub usernames (normalize case)
    'praneetaAD078': 'praneetaad078',
    'Rooba8925': 'rooba8925',
    'sadhana-095': 'sadhana-095',
    
    # Mock data (keep as-is for testing)
    'user_001': 'user_001',
    'user_002': 'user_002',
    'user_003': 'user_003',
    'user_004': 'user_004',
    'primary': 'primary',  # Calendar primary user
}

def normalize_user_id(user_id):
    """
    Convert any user identifier to standardized username
    
    Args:
        user_id: Original user identifier (Slack ID, email, GitHub username, etc.)
        
    Returns:
        Standardized lowercase username
    """
    if not user_id:
        return 'unknown'
    
    # Return mapped value or lowercase original
    return USER_MAPPING.get(user_id, user_id.lower())


def get_display_name(user_id):
    """
    Get a pretty display name for the dashboard
    
    Args:
        user_id: Standardized user ID
        
    Returns:
        Human-readable display name
    """
    display_names = {
        'praneetaad078': 'Praneeta',
        'rooba8925': 'Rooba',
        'sadhana-095': 'Sadhana',
        'team_calendar': 'Team Calendar',
    }
    
    return display_names.get(user_id, user_id.title())