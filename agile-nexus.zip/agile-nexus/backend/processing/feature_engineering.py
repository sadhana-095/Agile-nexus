import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from models import db, CalendarData, CommunicationData, CodeActivity
import logging

logger = logging.getLogger(__name__)

class FeatureEngineer:
    """Feature Engineering for ML Models - Using Real Data"""
    
    def __init__(self):
        self.features = {}
        self.real_team_members = ['rooba8925', 'praneetaad078', 'sadhana-095']
    
    def generate_all_features(self, days_back=7):
        """Generate all features for ML models using REAL data"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        
        logger.info(f"Generating REAL features from {start_date} to {end_date}")
        
        try:
            # Get REAL data from database
            calendar_data = self._get_calendar_data_real(start_date, end_date)
            comm_data = self._get_communication_data_real(start_date, end_date)
            code_data = self._get_code_data_real(start_date, end_date)
            
            logger.info(f"📊 Data retrieved: {len(calendar_data)} calendar events, {len(comm_data)} comm records, {len(code_data)} code activities")
            
            # Generate features from REAL data
            sprint_features = self._generate_sprint_features_from_real_data(
                calendar_data, comm_data, code_data
            )
            
            productivity_features = self._generate_productivity_features_from_real_data(
                calendar_data, comm_data
            )
            
            dependency_features = self._generate_dependency_features_from_real_data(
                code_data
            )
            
            logger.info(f"✅ Features generated: {len(sprint_features)} sprint, {len(productivity_features)} productivity, {len(dependency_features)} dependencies")
            
            return {
                'sprint_health': sprint_features,
                'productivity': productivity_features,
                'dependency': dependency_features,
                'data_source': 'real',
                'real_data_percentage': self._calculate_real_data_percentage(
                    calendar_data, comm_data, code_data
                )
            }
            
        except Exception as e:
            logger.error(f"Feature generation failed: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return self._generate_mock_features()
    
    def _get_calendar_data_real(self, start_date, end_date):
        """Get REAL calendar data"""
        try:
            calendar_records = CalendarData.query.filter(
                CalendarData.start_time >= start_date,
                CalendarData.start_time <= end_date
            ).all()
            
            data = []
            for record in calendar_records:
                data.append({
                    'user_id': record.user_id,
                    'event_type': record.event_type,
                    'start_time': record.start_time,
                    'end_time': record.end_time,
                    'title': record.title,
                    'attendee_count': record.attendee_count,
                    'data_source': record.data_source,
                    'date': record.date
                })
            
            real_count = len([d for d in data if d['data_source'] == 'real'])
            logger.info(f"📅 Calendar: {real_count} real, {len(data)-real_count} mock")
            
            return data
            
        except Exception as e:
            logger.error(f"Calendar query failed: {e}")
            return []
    
    def _get_communication_data_real(self, start_date, end_date):
        """Get REAL communication data from Slack"""
        try:
            comm_records = CommunicationData.query.filter(
                CommunicationData.date >= start_date.date(),
                CommunicationData.date <= end_date.date()
            ).all()
            
            data = []
            for record in comm_records:
                data.append({
                    'user_id': record.user_id,
                    'team_id': record.team_id,
                    'message_count': record.message_count,
                    'response_time_avg': record.response_time_avg,
                    'active_hours': record.active_hours,
                    'date': record.date,
                    'data_source': record.data_source
                })
            
            real_count = len([d for d in data if d['data_source'] == 'real'])
            logger.info(f"💬 Communication: {real_count} real, {len(data)-real_count} mock")
            
            return data
            
        except Exception as e:
            logger.error(f"Communication query failed: {e}")
            return []
    
    def _get_code_data_real(self, start_date, end_date):
        """Get REAL code activity from GitHub"""
        try:
            code_records = CodeActivity.query.filter(
                CodeActivity.date >= start_date.date(),
                CodeActivity.date <= end_date.date()
            ).all()
            
            data = []
            for record in code_records:
                data.append({
                    'user_id': record.user_id,
                    'repository': record.repository,
                    'commits_count': record.commits_count,
                    'lines_added': record.lines_added,
                    'lines_removed': record.lines_removed,
                    'date': record.date,
                    'data_source': record.data_source
                })
            
            real_count = len([d for d in data if d['data_source'] == 'real'])
            logger.info(f"💻 Code Activity: {real_count} real, {len(data)-real_count} mock")
            
            return data
            
        except Exception as e:
            logger.error(f"Code query failed: {e}")
            return []
    
    def _generate_sprint_features_from_real_data(self, calendar_data, comm_data, code_data):
        """Generate sprint health features from REAL data"""
        features = []
        
        # Get all unique users (prioritize real team members)
        users = set(self.real_team_members)
        
        # Add other users from data
        if calendar_data:
            users.update([item['user_id'] for item in calendar_data])
        if comm_data:
            users.update([item['user_id'] for item in comm_data])
        if code_data:
            users.update([item['user_id'] for item in code_data])
        
        for user_id in users:
            # Calendar metrics
            user_calendar = [item for item in calendar_data if item['user_id'] == user_id]
            meeting_hours = 0
            focus_hours = 0
            total_meetings = 0
            
            for event in user_calendar:
                if event['start_time'] and event['end_time']:
                    duration = (event['end_time'] - event['start_time']).total_seconds() / 3600
                    if event['event_type'] == 'meeting':
                        meeting_hours += duration
                        total_meetings += 1
                    elif event['event_type'] == 'focus':
                        focus_hours += duration
            
            # Communication metrics
            user_comm = [item for item in comm_data if item['user_id'] == user_id]
            total_messages = sum([item['message_count'] for item in user_comm])
            avg_response_time = np.mean([item['response_time_avg'] for item in user_comm]) if user_comm else 0
            
            # Code metrics from GitHub
            user_code = [item for item in code_data if item['user_id'] == user_id]
            total_commits = sum([item['commits_count'] for item in user_code])
            lines_added = sum([item['lines_added'] for item in user_code])
            lines_removed = sum([item['lines_removed'] for item in user_code])
            
            # Calculate derived features
            calendar_density = min((meeting_hours + focus_hours) / 40, 1.0)  # 40 hours work week
            productivity_score = self._calculate_productivity(
                focus_hours, meeting_hours, total_commits, total_messages
            )
            risk_score = self._calculate_risk(
                meeting_hours, focus_hours, total_commits, calendar_density
            )
            
            features.append({
                'user_id': user_id,
                'date': datetime.now().date(),
                'meeting_hours': round(meeting_hours, 2),
                'focus_hours': round(focus_hours, 2),
                'total_meetings': total_meetings,
                'total_messages': total_messages,
                'total_commits': total_commits,
                'lines_changed': lines_added + lines_removed,
                'calendar_density': round(calendar_density, 3),
                'productivity_score': round(productivity_score, 3),
                'risk_score': round(risk_score, 1),
                'avg_response_time': round(avg_response_time, 2) if avg_response_time else 0,
                'data_source': 'real' if user_id in self.real_team_members else 'mixed'
            })
        
        return features
    
    def _generate_productivity_features_from_real_data(self, calendar_data, comm_data):
        """Generate productivity features from REAL calendar and communication patterns"""
        features = []
        
        if not calendar_data:
            logger.warning("No calendar data for productivity features")
            return features
        
        # Analyze by hour and day patterns
        hour_day_patterns = {}
        
        for event in calendar_data:
            if not event['start_time']:
                continue
                
            hour = event['start_time'].hour
            day = event['start_time'].weekday()  # 0=Monday, 4=Friday
            
            key = (hour, day)
            if key not in hour_day_patterns:
                hour_day_patterns[key] = {
                    'focus': 0,
                    'meetings': 0,
                    'total_events': 0
                }
            
            hour_day_patterns[key]['total_events'] += 1
            if event['event_type'] == 'focus':
                hour_day_patterns[key]['focus'] += 1
            elif event['event_type'] == 'meeting':
                hour_day_patterns[key]['meetings'] += 1
        
        # Calculate productivity score for each hour/day combination
        for (hour, day), patterns in hour_day_patterns.items():
            # Productivity = high focus, low meetings
            focus_score = patterns['focus'] * 0.7
            meeting_penalty = patterns['meetings'] * 0.3
            productivity_score = max(0, focus_score - meeting_penalty) / max(patterns['total_events'], 1)
            
            features.append({
                'hour_of_day': hour,
                'day_of_week': day,
                'focus_events': patterns['focus'],
                'meeting_count': patterns['meetings'],
                'meeting_events': patterns['meetings'],
                'total_events': patterns['total_events'],
                'calendar_density': patterns['total_events'] / 4.0,  # Normalize
                'productivity_score': round(min(productivity_score, 1.0), 3),
                'message_activity': 0,  # Can be enhanced with comm_data
                'commit_activity': 0    # Can be enhanced with code_data
            })
        
        return features
    
    def _generate_dependency_features_from_real_data(self, code_data):
        """Generate REAL dependency features from GitHub repositories"""
        features = []
        
        if not code_data:
            logger.warning("No code data for dependency features - using sample")
            return self._generate_sample_dependencies()
        
        # Group by repository to find dependencies
        repo_users = {}
        for activity in code_data:
            repo = activity['repository']
            user = activity['user_id']
            
            if repo not in repo_users:
                repo_users[repo] = []
            repo_users[repo].append({
                'user_id': user,
                'commits': activity['commits_count'],
                'lines_changed': activity['lines_added'] + activity['lines_removed']
            })
        
        # Create dependencies based on shared repositories
        repo_list = list(repo_users.keys())
        for i, source_repo in enumerate(repo_list):
            for j, target_repo in enumerate(repo_list):
                if i != j:
                    # Calculate dependency risk based on code coupling
                    source_commits = sum(u['commits'] for u in repo_users[source_repo])
                    target_commits = sum(u['commits'] for u in repo_users[target_repo])
                    
                    # Higher commits = higher dependency risk
                    risk_probability = min((source_commits + target_commits) / 20.0, 0.9)
                    cascade_impact = min(len(repo_users[source_repo]) + len(repo_users[target_repo]), 5)
                    
                    features.append({
                        'source_story': f'REPO_{source_repo[:20]}',
                        'dependent_story': f'REPO_{target_repo[:20]}',
                        'dependency_type': 'blocks',
                        'risk_probability': round(risk_probability, 2),
                        'cascade_impact': cascade_impact,
                        'data_source': 'real'
                    })
        
        # If no real dependencies found, add sample ones
        if len(features) < 3:
            features.extend(self._generate_sample_dependencies())
        
        return features[:10]  # Limit to top 10 dependencies
    
    def _generate_sample_dependencies(self):
        """Generate sample dependencies as fallback"""
        return [
            {
                'source_story': 'EPIC_AUTH_SYSTEM',
                'dependent_story': 'STORY_LOGIN_API',
                'dependency_type': 'blocks',
                'risk_probability': 0.75,
                'cascade_impact': 4,
                'data_source': 'sample'
            },
            {
                'source_story': 'STORY_LOGIN_API',
                'dependent_story': 'STORY_USER_DASHBOARD',
                'dependency_type': 'blocks',
                'risk_probability': 0.60,
                'cascade_impact': 3,
                'data_source': 'sample'
            },
            {
                'source_story': 'EPIC_DATABASE_SCHEMA',
                'dependent_story': 'STORY_DATA_MIGRATION',
                'dependency_type': 'blocks',
                'risk_probability': 0.85,
                'cascade_impact': 5,
                'data_source': 'sample'
            }
        ]
    
    def _calculate_productivity(self, focus_hours, meeting_hours, commits, messages):
        """Calculate productivity score from real metrics"""
        # Weight different factors
        focus_score = min(focus_hours / 20, 1.0) * 0.4      # 20 hours focus/week is optimal
        commit_score = min(commits / 10, 1.0) * 0.3         # 10 commits/week is good
        message_score = min(messages / 50, 1.0) * 0.1       # Active communication
        meeting_penalty = min(meeting_hours / 15, 1.0) * 0.2  # Too many meetings hurt productivity
        
        return max(0, focus_score + commit_score + message_score - meeting_penalty)
    
    def _calculate_risk(self, meeting_hours, focus_hours, commits, calendar_density):
        """Calculate risk score based on real patterns"""
        risk = 0
        
        # Meeting overload risk
        if meeting_hours > 20:
            risk += 40
        elif meeting_hours > 15:
            risk += 25
        elif meeting_hours > 10:
            risk += 15
        
        # Low focus time risk
        if focus_hours < 5:
            risk += 30
        elif focus_hours < 10:
            risk += 15
        
        # Low code activity risk
        if commits == 0:
            risk += 30
        elif commits < 3:
            risk += 15
        
        # Calendar overload risk
        if calendar_density > 0.9:
            risk += 20
        elif calendar_density > 0.75:
            risk += 10
        
        return min(risk, 100)
    
    def _calculate_real_data_percentage(self, calendar_data, comm_data, code_data):
        """Calculate percentage of real vs mock data"""
        total = len(calendar_data) + len(comm_data) + len(code_data)
        if total == 0:
            return 0
        
        real = (
            len([d for d in calendar_data if d.get('data_source') == 'real']) +
            len([d for d in comm_data if d.get('data_source') == 'real']) +
            len([d for d in code_data if d.get('data_source') == 'real'])
        )
        
        return round((real / total) * 100, 1)
    
    def _generate_mock_features(self):
        """Generate mock features only as fallback"""
        logger.warning("⚠️ Using MOCK data as fallback")
        return {
            'sprint_health': [
                {
                    'user_id': 'rooba8925',
                    'meeting_hours': 4.5,
                    'focus_hours': 3.0,
                    'total_commits': 10,
                    'calendar_density': 0.65,
                    'productivity_score': 0.75,
                    'risk_score': 25,
                    'data_source': 'mock'
                },
                {
                    'user_id': 'praneetaad078',
                    'meeting_hours': 6.0,
                    'focus_hours': 2.0,
                    'total_commits': 6,
                    'calendar_density': 0.75,
                    'productivity_score': 0.55,
                    'risk_score': 45,
                    'data_source': 'mock'
                },
                {
                    'user_id': 'sadhana-095',
                    'meeting_hours': 3.5,
                    'focus_hours': 4.0,
                    'total_commits': 2,
                    'calendar_density': 0.60,
                    'productivity_score': 0.65,
                    'risk_score': 35,
                    'data_source': 'mock'
                }
            ],
            'productivity': [
                {'hour_of_day': 10, 'focus_events': 2, 'meeting_events': 1, 'productivity_score': 0.8},
                {'hour_of_day': 14, 'focus_events': 1, 'meeting_events': 2, 'productivity_score': 0.4}
            ],
            'dependency': self._generate_sample_dependencies(),
            'data_source': 'mock',
            'real_data_percentage': 0
        }
