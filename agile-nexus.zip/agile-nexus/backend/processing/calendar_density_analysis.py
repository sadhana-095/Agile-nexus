import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class CalendarDensityAnalyzer:
    """Calendar Density Analysis for productivity insights"""
    
    def __init__(self):
        self.density_thresholds = {
            'low': 0.3,
            'medium': 0.6,
            'high': 0.8,
            'overload': 1.0
        }
    
    def analyze_team_density(self, calendar_features):
        """Analyze calendar density across the team"""
        logger.info("Analyzing team calendar density")
        
        df = pd.DataFrame(calendar_features)
        if df.empty:
            logger.warning("Empty calendar features")
            return {}
        
        analysis = {
            'overall_stats': self._calculate_density_stats(df),
            'user_patterns': self._analyze_user_patterns(df),
            'risk_indicators': self._identify_risk_indicators(df),
            'recommendations': self._generate_recommendations(df)
        }
        
        return analysis
    
    def _calculate_density_stats(self, df):
        """Calculate overall density statistics"""
        stats = {}
        
        # ✅ Only calculate if columns exist
        if 'calendar_density' in df.columns:
            stats['avg_calendar_density'] = round(df['calendar_density'].mean(), 3)
            stats['high_density_days'] = len(df[df['calendar_density'] > self.density_thresholds['high']])
            stats['overload_days'] = len(df[df['calendar_density'] >= self.density_thresholds['overload']])
        
        if 'meeting_hours' in df.columns:
            stats['avg_meeting_hours'] = round(df['meeting_hours'].mean(), 2)
        
        if 'focus_hours' in df.columns:
            stats['avg_focus_hours'] = round(df['focus_hours'].mean(), 2)
            stats['low_focus_days'] = len(df[df['focus_hours'] < 2])
        
        return stats
    
    def _analyze_user_patterns(self, df):
        """Analyze patterns for each user"""
        user_patterns = {}
        
        if 'user_id' not in df.columns:
            logger.warning("No 'user_id' column found")
            return user_patterns
        
        for user_id in df['user_id'].unique():
            user_data = df[df['user_id'] == user_id]
            
            pattern = {}
            
            if 'calendar_density' in df.columns:
                pattern['avg_density'] = round(user_data['calendar_density'].mean(), 3)
                pattern['density_category'] = self._categorize_density(user_data['calendar_density'].mean())
            
            if 'total_meetings' in df.columns:
                pattern['meeting_pattern'] = self._analyze_meeting_pattern(user_data)
            
            if 'productivity_score' in df.columns and 'calendar_density' in df.columns:
                pattern['productivity_correlation'] = self._calculate_productivity_correlation(user_data)
            
            if 'risk_score' in df.columns:
                pattern['risk_days'] = len(user_data[user_data['risk_score'] > 50])
            
            user_patterns[user_id] = pattern
        
        return user_patterns
    
    def _categorize_density(self, density_value):
        """Categorize density level"""
        if density_value <= self.density_thresholds['low']:
            return 'low'
        elif density_value <= self.density_thresholds['medium']:
            return 'medium'
        elif density_value <= self.density_thresholds['high']:
            return 'high'
        else:
            return 'overload'
    
    def _analyze_meeting_pattern(self, user_data):
        """Analyze meeting patterns for a user"""
        if 'total_meetings' not in user_data.columns:
            return {}
        
        return {
            'avg_daily_meetings': round(user_data['total_meetings'].mean(), 1),
            'heavy_meeting_days': len(user_data[user_data['total_meetings'] > 5]),
            'meeting_free_days': len(user_data[user_data['total_meetings'] == 0]),
            'optimal_meeting_days': len(user_data[
                (user_data['total_meetings'] >= 2) & (user_data['total_meetings'] <= 4)
            ])
        }
    
    def _calculate_productivity_correlation(self, user_data):
        """Calculate correlation between calendar density and productivity"""
        if len(user_data) < 3:
            return 0
        
        if 'calendar_density' not in user_data.columns or 'productivity_score' not in user_data.columns:
            return 0
        
        correlation = np.corrcoef(
            user_data['calendar_density'], 
            user_data['productivity_score']
        )[0, 1]
        
        return round(correlation, 3) if not np.isnan(correlation) else 0
    
    def _identify_risk_indicators(self, df):
        """Identify risk indicators from calendar density"""
        total_days = len(df)
        indicators = {}
        
        if 'user_id' in df.columns and 'risk_score' in df.columns:
            indicators['high_risk_users'] = list(
                df.groupby('user_id')['risk_score'].mean().sort_values(ascending=False).head(3).index
            )
        
        if 'calendar_density' in df.columns:
            indicators['overloaded_days_pct'] = round(
                (len(df[df['calendar_density'] > 0.8]) / total_days * 100) if total_days > 0 else 0, 
                1
            )
        
        if 'productivity_score' in df.columns:
            indicators['low_productivity_days'] = len(df[df['productivity_score'] < 0.3])
        
        if 'user_id' in df.columns and 'meeting_hours' in df.columns:
            indicators['meeting_overload_users'] = list(
                df.groupby('user_id')['meeting_hours'].mean().sort_values(ascending=False).head(2).index
            )
        
        if 'user_id' in df.columns and 'focus_hours' in df.columns:
            indicators['focus_deficit_users'] = list(
                df.groupby('user_id')['focus_hours'].mean().sort_values(ascending=True).head(2).index
            )
        
        return indicators
    
    def _generate_recommendations(self, df):
        """Generate actionable recommendations"""
        recommendations = []
        
        if 'user_id' not in df.columns:
            return recommendations
        
        # Density-based recommendations
        if 'calendar_density' in df.columns:
            high_density_users = df.groupby('user_id')['calendar_density'].mean().sort_values(ascending=False)
            if not high_density_users.empty and high_density_users.iloc[0] > 0.8:
                recommendations.append({
                    'type': 'calendar_optimization',
                    'priority': 'high',
                    'message': f'User {high_density_users.index[0]} has calendar overload - consider reducing meetings',
                    'suggested_action': 'Block focus time slots'
                })
        
        # Focus time recommendations
        if 'focus_hours' in df.columns:
            low_focus_users = df.groupby('user_id')['focus_hours'].mean().sort_values(ascending=True)
            if not low_focus_users.empty and low_focus_users.iloc[0] < 2:
                recommendations.append({
                    'type': 'focus_time',
                    'priority': 'medium',
                    'message': f'User {low_focus_users.index[0]} needs more focus time',
                    'suggested_action': 'Schedule 2-hour focus blocks daily'
                })
        
        # Team-level recommendations
        if 'calendar_density' in df.columns:
            avg_density = df['calendar_density'].mean()
            if avg_density > 0.7:
                recommendations.append({
                    'type': 'team_optimization',
                    'priority': 'high',
                    'message': 'Team calendar density is too high - risk of burnout',
                    'suggested_action': 'Implement no-meeting days or time blocks'
                })
        
        return recommendations
