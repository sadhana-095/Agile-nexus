from .feature_engineering import FeatureEngineer
from .time_series_aggregation import TimeSeriesAggregator
from .calendar_density_analysis import CalendarDensityAnalyzer
from .user_mapping import normalize_user_id  # ✅ ADD THIS
import logging

logger = logging.getLogger(__name__)

class ProcessingCoordinator:
    """Coordinates all processing modules"""
    
    def __init__(self):
        self.feature_engineer = FeatureEngineer()
        self.time_series_aggregator = TimeSeriesAggregator()
        self.calendar_analyzer = CalendarDensityAnalyzer()
    
    def run_full_processing(self, days_back=7, include_mock=False):
        """Run all processing modules"""
        logger.info("Starting full data processing pipeline")
        
        try:
            # Step 1: Feature Engineering
            features = self.feature_engineer.generate_all_features(days_back)
            
            # ✅ Step 2: Normalize all user IDs
            normalized_sprint = self._normalize_features(features['sprint_health'])
            normalized_productivity = self._normalize_features(features['productivity'])
            normalized_dependency = self._normalize_dependencies(features['dependency'])
            
            # ✅ Step 3: Filter out mock data if requested
            if not include_mock:
                normalized_sprint = self._filter_real_users(normalized_sprint)
                normalized_productivity = self._filter_real_users(normalized_productivity)
                
                normalized_dependency = self._filter_real_users(normalized_dependency)
            # Simple processing results
            results = {
                'features_generated': {
                    'sprint_health_features': len(normalized_sprint),
                    'productivity_features': len(normalized_productivity),
                    'dependency_features': len(normalized_dependency)
                },
                'sample_sprint_features': normalized_sprint[:3],
                'sample_productivity_features': normalized_productivity[:5],
                'sample_dependency_features': normalized_dependency,
                'processing_status': 'completed',
                'data_filtered': not include_mock  # ✅ Show filter status
            }
            
            logger.info("Data processing completed successfully")
            return results
            
        except Exception as e:
            logger.error(f"Processing failed: {e}")
            return {
                'error': str(e),
                'processing_status': 'failed'
            }
    
    def _normalize_features(self, features):
        """Normalize user_id in feature dictionaries"""
        normalized = []
        for feature in features:
            if 'user_id' in feature:
                feature = feature.copy()  # Don't modify original
                feature['user_id'] = normalize_user_id(feature['user_id'])
            normalized.append(feature)
        return normalized
    
    def _normalize_dependencies(self, dependencies):
        """Normalize user IDs in dependency chains"""
        normalized = []
        for dep in dependencies:
            dep = dep.copy()
            # Dependencies might have source_story/dependent_story instead of user_id
            # Adjust if your dependency structure uses user_id
            if 'user_id' in dep:
                dep['user_id'] = normalize_user_id(dep['user_id'])
            normalized.append(dep)
        return normalized

    # ✅ ADD THIS NEW METHOD
    def _filter_real_users(self, features):
        """Filter out mock/test users, keep only real team members"""
        REAL_USERS = {'praneetaad078', 'rooba8925', 'sadhana-095'}
        
        filtered = [
            feature for feature in features
            if feature.get('user_id') in REAL_USERS
        ]
        
        logger.info(f"Filtered {len(features)} -> {len(filtered)} (real users only)")
        return filtered