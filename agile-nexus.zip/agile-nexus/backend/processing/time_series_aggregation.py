import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class TimeSeriesAggregator:
    """Time-Series Aggregation for trend analysis"""
    
    def __init__(self):
        self.aggregated_data = {}
    
    def aggregate_sprint_metrics(self, features_data):
        """Aggregate sprint health metrics over time"""
        logger.info("Aggregating sprint health time series")
        
        df = pd.DataFrame(features_data)
        if df.empty:
            logger.warning("Empty sprint features data")
            return []
        
        # ✅ Handle missing date column
        if 'date' not in df.columns:
            logger.warning("No 'date' column found, using current date")
            df['date'] = pd.Timestamp.now().normalize()
        
        df['date'] = pd.to_datetime(df['date'])
        
        # ✅ Build aggregation dict dynamically based on available columns
        agg_dict = {}
        
        if 'meeting_hours' in df.columns:
            agg_dict['meeting_hours'] = ['mean', 'std']
        if 'focus_hours' in df.columns:
            agg_dict['focus_hours'] = ['mean', 'std']
        if 'calendar_density' in df.columns:
            agg_dict['calendar_density'] = 'mean'
        if 'productivity_score' in df.columns:
            agg_dict['productivity_score'] = 'mean'
        if 'risk_score' in df.columns:
            agg_dict['risk_score'] = 'mean'
        
        # ✅ CRITICAL FIX: Use exact column names from your data
        if 'total_messages' in df.columns:
            agg_dict['total_messages'] = 'sum'
        if 'total_commits' in df.columns:
            agg_dict['total_commits'] = 'sum'
        
        if not agg_dict:
            logger.warning("No valid columns found for aggregation")
            return []
        
        # Daily aggregations
        try:
            daily_agg = df.groupby('date').agg(agg_dict).round(3)
            
            # Flatten multi-level column names
            daily_agg.columns = ['_'.join(col).strip() if isinstance(col, tuple) else col 
                                 for col in daily_agg.columns]
            daily_agg = daily_agg.reset_index()
            
            # Calculate trends if productivity_score exists
            if 'productivity_score_mean' in daily_agg.columns:
                daily_agg['productivity_trend'] = daily_agg['productivity_score_mean'].pct_change().fillna(0)
            if 'risk_score_mean' in daily_agg.columns:
                daily_agg['risk_trend'] = daily_agg['risk_score_mean'].pct_change().fillna(0)
            
            return daily_agg.to_dict('records')
            
        except Exception as e:
            logger.error(f"Error in aggregate_sprint_metrics: {str(e)}")
            return []
    
    def aggregate_productivity_patterns(self, productivity_data):
        """Aggregate productivity patterns by hour"""
        logger.info("Aggregating productivity time series")
        
        df = pd.DataFrame(productivity_data)
        if df.empty:
            logger.warning("Empty productivity data")
            return []
        
        # ✅ Check if hour_of_day exists
        if 'hour_of_day' not in df.columns:
            logger.warning("No 'hour_of_day' column found in productivity data")
            return []
        
        # Build aggregation dict
        agg_dict = {}
        if 'productivity_score' in df.columns:
            agg_dict['productivity_score'] = ['mean', 'std']
        if 'focus_events' in df.columns:
            agg_dict['focus_events'] = 'sum'
        if 'meeting_count' in df.columns:
            agg_dict['meeting_count'] = 'sum'
        elif 'meeting_events' in df.columns:  # ✅ Fallback
            agg_dict['meeting_events'] = 'sum'
        
        if not agg_dict:
            logger.warning("No valid columns for productivity aggregation")
            return []
        
        try:
            # Hourly patterns across all users
            hourly_agg = df.groupby('hour_of_day').agg(agg_dict).round(3)
            
            hourly_agg.columns = ['_'.join(col).strip() if isinstance(col, tuple) else col 
                                 for col in hourly_agg.columns]
            hourly_agg = hourly_agg.reset_index()
            
            # Identify peak productivity hours
            if 'productivity_score_mean' in hourly_agg.columns:
                max_productivity = hourly_agg['productivity_score_mean'].max()
                if max_productivity > 0:
                    hourly_agg['is_peak_hour'] = hourly_agg['productivity_score_mean'] > (max_productivity * 0.8)
                else:
                    hourly_agg['is_peak_hour'] = False
            
            return hourly_agg.to_dict('records')
            
        except Exception as e:
            logger.error(f"Error in aggregate_productivity_patterns: {str(e)}")
            return []
    
    def calculate_velocity_trends(self, features_data, window_size=3):
        """Calculate team velocity trends"""
        logger.info("Calculating velocity trends")
        
        df = pd.DataFrame(features_data)
        if df.empty:
            logger.warning("Empty features data for velocity")
            return []
        
        # ✅ Handle missing date
        if 'date' not in df.columns:
            logger.warning("No 'date' column found for velocity trends")
            df['date'] = pd.Timestamp.now().normalize()
        
        df['date'] = pd.to_datetime(df['date'])
        
        # ✅ CRITICAL FIX: Use correct column names
        agg_dict = {}
        if 'total_commits' in df.columns:
            agg_dict['total_commits'] = 'sum'
        if 'lines_changed' in df.columns:
            agg_dict['lines_changed'] = 'sum'
        if 'productivity_score' in df.columns:
            agg_dict['productivity_score'] = 'mean'
        
        if not agg_dict:
            logger.warning("No valid columns for velocity calculation")
            return []
        
        try:
            # Daily velocity metrics
            daily_velocity = df.groupby('date').agg(agg_dict).reset_index()
            
            # Calculate rolling averages
            if 'total_commits' in daily_velocity.columns:
                daily_velocity['commit_trend'] = daily_velocity['total_commits'].rolling(
                    window=window_size, min_periods=1
                ).mean().round(2)
            
            if 'productivity_score' in daily_velocity.columns:
                daily_velocity['productivity_trend'] = daily_velocity['productivity_score'].rolling(
                    window=window_size, min_periods=1
                ).mean().round(3)
            
            return daily_velocity.to_dict('records')
            
        except Exception as e:
            logger.error(f"Error in calculate_velocity_trends: {str(e)}")
            return []