import os
from github import Github

github_token = os.getenv('GITHUB_TOKEN')

print("\n" + "="*60)
print("Checking GitHub Token Permissions")
print("="*60)

try:
    g = Github(github_token)
    
    # Get token info
    auth = g.get_user()
    
    print(f"\n✅ Token is valid")
    print(f"Username: {auth.login}")
    
    # Try to access private repos
    repos = list(auth.get_repos())
    
    public_count = sum(1 for r in repos if not r.private)
    private_count = sum(1 for r in repos if r.private)
    
    print(f"\nRepositories accessible:")
    print(f"  Public: {public_count}")
    print(f"  Private: {private_count}")
    
    if private_count == 0:
        print("\n❌ Token CANNOT access private repositories")
        print("\nYour token needs 'repo' scope (full control)")
        print("Current token likely only has 'public_repo' scope")
    else:
        print("\n✅ Token CAN access private repositories")
    
    print("\nAll repositories:")
    for repo in repos:
        print(f"  {'🔒' if repo.private else '📖'} {repo.name}")
    
except Exception as e:
    print(f"❌ Error: {e}")