"""
Create demo users for Agile Nexus
"""
from app import create_app
from models import db, User
from datetime import datetime

app = create_app()

demo_users = [
    {
        'username': 'manager',
        'email': 'manager@agilenexus.ai',
        'full_name': 'Project Manager',
        'password': 'manager123',
        'role': 'manager'
    },
    {
        'username': 'rooba8925',
        'email': 'roobabaskaran194@gmail.com',
        'full_name': 'Rooba B',
        'password': 'rooba123',
        'role': 'member'
    },
    {
        'username': 'praneetaad078',
        'email': 'praneeta@agilenexus.ai',
        'full_name': 'Praneeta R',
        'password': 'praneeta123',
        'role': 'member'
    },
    {
        'username': 'sadhana-095',
        'email': 'sadhana@agilenexus.ai',
        'full_name': 'Sadhana G',
        'password': 'sadhana123',
        'role': 'member'
    }
]

with app.app_context():
    print("\n" + "="*70)
    print("CREATING DEMO USERS FOR AGILE NEXUS")
    print("="*70)
    
    db.create_all()
    print("\n✅ Users table created/verified")
    
    for user_data in demo_users:
        try:
            existing_user = User.query.filter_by(username=user_data['username']).first()
            
            if existing_user:
                print(f"\n⏭️  User '{user_data['username']}' already exists")
                continue
            
            new_user = User(
                username=user_data['username'],
                email=user_data['email'],
                full_name=user_data['full_name'],
                role=user_data['role'],
                created_at=datetime.utcnow()
            )
            new_user.set_password(user_data['password'])
            
            db.session.add(new_user)
            db.session.commit()
            
            print(f"\n✅ Created: {user_data['full_name']} (@{user_data['username']})")
            
        except Exception as e:
            print(f"\n❌ Error: {e}")
            db.session.rollback()
    
    print("\n" + "="*70)
    print("LOGIN CREDENTIALS")
    print("="*70)
    print("\nManager:")
    print("   Username: manager | Password: manager123")
    print("\nTeam Members:")
    print("   Username: rooba    | Password: rooba123")
    print("   Username: praneeta | Password: praneeta123")
    print("   Username: sadhana  | Password: sadhana123")
    print("\n" + "="*70)