from .base_model import BaseMLModel
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, r2_score
import xgboost as xgb
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class SprintHealthPredictor(BaseMLModel):
    """AI model to predict sprint failure risk (0-100%)"""
    
    def __init__(self):
        super().__init__("sprint_health_predictor")
        self.model_name = 'sprint_health_predictor'  # ✅ Should have this
        self.rf_model = None
        self.xgb_model = None
        self.scaler = StandardScaler()
        self.feature_columns = [
            'meeting_hours', 'focus_hours', 'total_messages', 
            'total_commits', 'calendar_density', 'productivity_score'
        ]
    
    def prepare_features(self, data):
        """Prepare features for training/prediction"""
        if not data:
            return np.array([]).reshape(0, len(self.feature_columns))
        
        df = pd.DataFrame(data)
        
        # Ensure all required columns exist
        for col in self.feature_columns:
            if col not in df.columns:
                df[col] = 0
        
        # Select and order features
        features = df[self.feature_columns].fillna(0)
        return features.values
    
    def train(self, training_data):
        """Train both Random Forest and XGBoost models"""
        logger.info("Training Sprint Health Predictor models")
        
        try:
            # Prepare features and targets
            X = self.prepare_features(training_data)
            
            if len(training_data) > 0 and 'risk_score' in training_data[0]:
                y = np.array([item['risk_score'] for item in training_data])
            else:
                # Generate synthetic targets for demo
                y = self._generate_synthetic_targets(X)
            
            if len(X) < 5:
                # Generate more synthetic data for training
                X, y = self._generate_synthetic_training_data(50)
            
            # Scale features
            X_scaled = self.scaler.fit_transform(X)
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X_scaled, y, test_size=0.2, random_state=42
            )
            
            # Train Random Forest
            self.rf_model = RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                random_state=42
            )
            self.rf_model.fit(X_train, y_train)
            
            # Train XGBoost
            self.xgb_model = xgb.XGBRegressor(
                n_estimators=100,
                max_depth=6,
                learning_rate=0.1,
                random_state=42
            )
            self.xgb_model.fit(X_train, y_train)
            
            # Evaluate models
            rf_score = self.rf_model.score(X_test, y_test)
            xgb_score = self.xgb_model.score(X_test, y_test)
            
            self.model = {
                'rf_model': self.rf_model,
                'xgb_model': self.xgb_model,
                'scaler': self.scaler,
                'rf_score': rf_score,
                'xgb_score': xgb_score
            }
            
            self.is_trained = True
            self.last_training = datetime.now()
            
            logger.info(f"Training completed - RF Score: {rf_score:.3f}, XGB Score: {xgb_score:.3f}")
            
            return {
                'status': 'success',
                'rf_accuracy': float(rf_score),  # Convert to Python float
                'xgb_accuracy': float(xgb_score),  # Convert to Python float
                'training_samples': int(len(X))  # Convert to Python int
            }
            
        except Exception as e:
            logger.error(f"Training failed: {e}")
            return {'status': 'failed', 'error': str(e)}
    
    def predict(self, input_data):
        """Predict sprint failure risk"""
        if not self.is_trained:
            if not self.load_model():
                return {'error': 'Model not trained. Please train the model first.'}
        
        try:
            # Prepare features
            X = self.prepare_features(input_data)
            X_scaled = self.scaler.transform(X)
            
            # Get predictions from both models
            rf_predictions = self.rf_model.predict(X_scaled)
            xgb_predictions = self.xgb_model.predict(X_scaled)
            
            # Ensemble prediction (average)
            ensemble_predictions = (rf_predictions + xgb_predictions) / 2
            
            # Ensure predictions are in 0-100 range
            ensemble_predictions = np.clip(ensemble_predictions, 0, 100)
            
            # Generate detailed results with JSON-safe conversions
            results = []
            for i, pred in enumerate(ensemble_predictions):
                risk_level = self._categorize_risk(pred)
                
                results.append({
                    'user_id': input_data[i].get('user_id', f'user_{i}'),
                    'predicted_risk_score': float(pred),  # Convert to Python float
                    'risk_level': risk_level,
                    'rf_prediction': float(rf_predictions[i]),  # Convert to Python float
                    'xgb_prediction': float(xgb_predictions[i]),  # Convert to Python float
                    'recommendations': self._generate_recommendations(float(pred), input_data[i])
                })
            
            return {
                'predictions': results,
                'model_info': {
                    'last_training': self.last_training.isoformat() if self.last_training else None,
                    'rf_accuracy': float(self.model['rf_score']) if self.model and 'rf_score' in self.model else 0.0,
                    'xgb_accuracy': float(self.model['xgb_score']) if self.model and 'xgb_score' in self.model else 0.0
                }
            }
            
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            return {'error': str(e)}
    
    def _generate_synthetic_targets(self, X):
        """Generate synthetic risk scores based on features"""
        targets = []
        for row in X:
            # meeting_hours, focus_hours, messages, commits, density, productivity
            risk = 0
            
            # High meeting hours increase risk
            if row[0] > 5:  # meeting_hours
                risk += 25
            
            # Low focus hours increase risk
            if row[1] < 2:  # focus_hours
                risk += 30
            
            # High calendar density increases risk
            if row[4] > 0.8:  # calendar_density
                risk += 20
            
            # Low commits increase risk
            if row[3] < 1:  # commits
                risk += 25
            
            # Low productivity increases risk
            if row[5] < 0.5:  # productivity_score
                risk += 15
            
            # Add some noise
            risk += np.random.normal(0, 5)
            targets.append(max(0, min(100, risk)))
        
        return np.array(targets)
    
    def _generate_synthetic_training_data(self, n_samples=50):
        """Generate synthetic training data"""
        np.random.seed(42)
        
        X = []
        for _ in range(n_samples):
            meeting_hours = np.random.uniform(1, 8)
            focus_hours = np.random.uniform(0, 6)
            messages = np.random.randint(10, 60)
            commits = np.random.randint(0, 8)
            density = np.random.uniform(0.2, 1.0)
            productivity = np.random.uniform(0.1, 1.0)
            
            X.append([meeting_hours, focus_hours, messages, commits, density, productivity])
        
        X = np.array(X)
        y = self._generate_synthetic_targets(X)
        
        return X, y
    
    def _categorize_risk(self, risk_score):
        """Categorize risk level"""
        if risk_score < 25:
            return 'Low'
        elif risk_score < 50:
            return 'Medium'
        elif risk_score < 75:
            return 'High'
        else:
            return 'Critical'
    
    def _generate_recommendations(self, risk_score, user_data):
        """Generate recommendations based on risk score"""
        recommendations = []
        
        if risk_score > 70:
            recommendations.append("URGENT: Reduce meeting load immediately")
            recommendations.append("Block 2-4 hour focus time slots")
        elif risk_score > 50:
            recommendations.append("Consider reducing non-essential meetings")
            recommendations.append("Schedule dedicated focus time")
        elif risk_score > 25:
            recommendations.append("Monitor calendar density")
            recommendations.append("Maintain current productivity patterns")
        else:
            recommendations.append("Good productivity balance maintained")
        
        return recommendations