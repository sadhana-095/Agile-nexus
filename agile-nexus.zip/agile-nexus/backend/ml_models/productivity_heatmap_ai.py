from .base_model import BaseMLModel
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class ProductivityHeatmapAI(BaseMLModel):
    """AI model to predict productivity zones and optimal scheduling"""
    
    def __init__(self):
        super().__init__("productivity_heatmap_ai")
        self.model_name = 'productivity_heatmap_ai'  # ✅ Should have this
        self.kmeans_model = None
        self.svr_model = None
        self.feature_scaler = StandardScaler()
        self.target_scaler = MinMaxScaler()
        self.feature_columns = [
            'hour_of_day', 'day_of_week', 'meeting_count', 'focus_events',
            'calendar_density', 'message_activity', 'commit_activity'
        ]
        self.productivity_zones = {}
    
    def prepare_features(self, data):
        """Prepare features for training/prediction"""
        if not data:
            return np.array([]).reshape(0, len(self.feature_columns))
        
        df = pd.DataFrame(data)
        
        # Create additional features if missing
        if 'day_of_week' not in df.columns and 'hour_of_day' in df.columns:
            # Mock day of week (0=Monday, 6=Sunday)
            df['day_of_week'] = np.random.randint(0, 5, len(df))  # Weekdays only
        
        if 'meeting_count' not in df.columns:
            df['meeting_count'] = df.get('meeting_events', 0)
        
        if 'message_activity' not in df.columns:
            df['message_activity'] = np.random.randint(5, 50, len(df))
        
        if 'commit_activity' not in df.columns:
            df['commit_activity'] = np.random.randint(0, 10, len(df))
        
        if 'calendar_density' not in df.columns:
            df['calendar_density'] = np.random.uniform(0.3, 0.9, len(df))
        
        # Ensure all required columns exist
        for col in self.feature_columns:
            if col not in df.columns:
                df[col] = 0
        
        # Select and order features
        features = df[self.feature_columns].fillna(0)
        return features.values
    
    def train(self, training_data):
        """Train K-Means clustering and SVR regression models"""
        logger.info("Training Productivity Heatmap AI models")
        
        try:
            # Prepare features
            X = self.prepare_features(training_data)
            
            # Create productivity targets if not provided
            if len(training_data) > 0 and 'productivity_score' in training_data[0]:
                y = np.array([item['productivity_score'] for item in training_data])
            else:
                y = self._generate_productivity_targets(X)
            
            if len(X) < 10:
                # Generate more synthetic data for training
                X, y = self._generate_synthetic_training_data(100)
            
            # Scale features and targets
            X_scaled = self.feature_scaler.fit_transform(X)
            y_scaled = self.target_scaler.fit_transform(y.reshape(-1, 1)).ravel()
            
            # Train K-Means for productivity zones
            self.kmeans_model = KMeans(
                n_clusters=4,  # High, Medium, Low, Very Low productivity zones
                random_state=42,
                n_init=10
            )
            clusters = self.kmeans_model.fit_predict(X_scaled)
            
            # Create productivity zone mapping
            self._create_productivity_zones(X, y, clusters)
            
            # Train SVR for productivity prediction
            X_train, X_test, y_train, y_test = train_test_split(
                X_scaled, y_scaled, test_size=0.2, random_state=42
            )
            
            self.svr_model = SVR(
                kernel='rbf',
                C=100,
                gamma='scale',
                epsilon=0.1
            )
            self.svr_model.fit(X_train, y_train)
            
            # Evaluate models
            y_pred = self.svr_model.predict(X_test)
            y_pred_original = self.target_scaler.inverse_transform(y_pred.reshape(-1, 1)).ravel()
            y_test_original = self.target_scaler.inverse_transform(y_test.reshape(-1, 1)).ravel()
            
            mae = mean_absolute_error(y_test_original, y_pred_original)
            r2 = r2_score(y_test_original, y_pred_original)
            
            # Calculate silhouette score for clustering
            from sklearn.metrics import silhouette_score
            silhouette_avg = silhouette_score(X_scaled, clusters)
            
            self.model = {
                'kmeans_model': self.kmeans_model,
                'svr_model': self.svr_model,
                'feature_scaler': self.feature_scaler,
                'target_scaler': self.target_scaler,
                'productivity_zones': self.productivity_zones,
                'mae': mae,
                'r2_score': r2,
                'silhouette_score': silhouette_avg
            }
            
            self.is_trained = True
            self.last_training = datetime.now()
            
            logger.info(f"Training completed - MAE: {mae:.3f}, R2: {r2:.3f}, Silhouette: {silhouette_avg:.3f}")
            
            return {
                'status': 'success',
                'mae': float(mae),
                'r2_score': float(r2),
                'silhouette_score': float(silhouette_avg),
                'training_samples': int(len(X)),
                'productivity_zones': len(self.productivity_zones)
            }
            
        except Exception as e:
            logger.error(f"Training failed: {e}")
            return {'status': 'failed', 'error': str(e)}
    
    def predict(self, input_data):
        """Predict productivity scores and optimal zones"""
        if not self.is_trained:
            if not self.load_model():
                return {'error': 'Model not trained. Please train the model first.'}
        
        try:
            # Prepare features
            X = self.prepare_features(input_data)
            X_scaled = self.feature_scaler.transform(X)
            
            # Get cluster predictions (productivity zones)
            cluster_predictions = self.kmeans_model.predict(X_scaled)
            
            # Get productivity score predictions
            productivity_predictions_scaled = self.svr_model.predict(X_scaled)
            productivity_predictions = self.target_scaler.inverse_transform(
                productivity_predictions_scaled.reshape(-1, 1)
            ).ravel()
            
            # CRITICAL FIX: Clip predictions to valid range [0, 1]
            productivity_predictions = np.clip(productivity_predictions, 0.0, 1.0)
            
            # Generate detailed results
            results = []
            for i, (cluster, productivity) in enumerate(zip(cluster_predictions, productivity_predictions)):
                zone_info = self._get_zone_info(cluster)
                optimal_times = self._get_optimal_scheduling_times(float(productivity), input_data[i])
                
                results.append({
                    'user_id': input_data[i].get('user_id', f'user_{i}'),
                    'hour_of_day': int(input_data[i].get('hour_of_day', 9)),
                    'predicted_productivity': float(productivity),
                    'productivity_zone': zone_info['zone_name'],
                    'zone_description': zone_info['description'],
                    'cluster_id': int(cluster),
                    'optimal_for_tasks': zone_info['optimal_tasks'],
                    'scheduling_recommendations': optimal_times
                })
            
            # Generate heatmap data
            heatmap_data = self._generate_heatmap_data(results)
            
            return {
                'predictions': results,
                'heatmap_data': heatmap_data,
                'model_info': {
                    'last_training': self.last_training.isoformat() if self.last_training else None,
                    'mae': float(self.model['mae']) if self.model and 'mae' in self.model else 0.0,
                    'r2_score': float(self.model['r2_score']) if self.model and 'r2_score' in self.model else 0.0
                }
            }
            
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            return {'error': str(e)}
    
    def get_team_heatmap(self, days_back=7):
        """Generate team-wide productivity heatmap"""
        try:
            # Generate sample data for team heatmap
            hours = list(range(9, 18))  # 9 AM to 5 PM
            days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
            
            heatmap_matrix = []
            for day_idx, day in enumerate(days):
                day_data = []
                for hour in hours:
                    # Create sample input for prediction
                    sample_input = [{
                        'hour_of_day': hour,
                        'day_of_week': day_idx,
                        'meeting_count': np.random.randint(0, 3),
                        'focus_events': np.random.randint(0, 2),
                        'calendar_density': np.random.uniform(0.3, 0.8),
                        'message_activity': np.random.randint(10, 40),
                        'commit_activity': np.random.randint(0, 5)
                    }]
                    
                    # Get productivity prediction
                    if self.is_trained:
                        prediction = self.predict(sample_input)
                        if 'error' not in prediction:
                            productivity = prediction['predictions'][0]['predicted_productivity']
                        else:
                            productivity = np.random.uniform(0.3, 0.9)
                    else:
                        productivity = np.random.uniform(0.3, 0.9)
                    
                    day_data.append(float(productivity))
                
                heatmap_matrix.append(day_data)
            
            return {
                'heatmap_matrix': heatmap_matrix,
                'hours': hours,
                'days': days,
                'optimal_slots': self._identify_optimal_slots(heatmap_matrix, hours, days)
            }
            
        except Exception as e:
            logger.error(f"Heatmap generation failed: {e}")
            return {'error': str(e)}
    
    def _generate_productivity_targets(self, X):
        """Generate realistic productivity targets based on features"""
        targets = []
        for row in X:
            hour, day_of_week, meetings, focus, density, messages, commits = row
            
            productivity = 0.5  # Base productivity
            
            # Time-of-day effects
            if 9 <= hour <= 11:  # Morning peak
                productivity += 0.3
            elif 14 <= hour <= 15:  # Afternoon moderate
                productivity += 0.1
            elif hour >= 16:  # Late afternoon decline
                productivity -= 0.2
            
            # Meeting effects
            if meetings == 0:
                productivity += 0.2  # No meetings boost
            elif meetings > 2:
                productivity -= 0.3  # Too many meetings penalty
            
            # Focus time boost
            productivity += focus * 0.15
            
            # Calendar density effects
            if density > 0.8:
                productivity -= 0.2
            elif density < 0.4:
                productivity += 0.1
            
            # Add some noise
            productivity += np.random.normal(0, 0.1)
            
            targets.append(max(0.1, min(1.0, productivity)))
        
        return np.array(targets)
    
    def _generate_synthetic_training_data(self, n_samples=100):
        """Generate synthetic training data"""
        np.random.seed(42)
        
        X = []
        for _ in range(n_samples):
            hour = np.random.randint(9, 18)
            day_of_week = np.random.randint(0, 5)  # Weekdays only
            meetings = np.random.randint(0, 4)
            focus = np.random.randint(0, 3)
            density = np.random.uniform(0.2, 1.0)
            messages = np.random.randint(5, 60)
            commits = np.random.randint(0, 8)
            
            X.append([hour, day_of_week, meetings, focus, density, messages, commits])
        
        X = np.array(X)
        y = self._generate_productivity_targets(X)
        
        return X, y
    
    def _create_productivity_zones(self, X, y, clusters):
        """Create productivity zone mapping"""
        unique_clusters = np.unique(clusters)
        
        # Calculate average productivity for each cluster
        cluster_productivities = {}
        for cluster in unique_clusters:
            cluster_mask = clusters == cluster
            avg_productivity = np.mean(y[cluster_mask])
            cluster_productivities[cluster] = avg_productivity
        
        # Sort clusters by productivity
        sorted_clusters = sorted(cluster_productivities.items(), key=lambda x: x[1], reverse=True)
        
        zone_names = ['Peak Performance', 'High Productivity', 'Moderate Productivity', 'Low Productivity']
        zone_descriptions = [
            'Optimal time for complex tasks and important decisions',
            'Good for focused work and meetings',
            'Suitable for routine tasks and collaboration',
            'Best for administrative work and breaks'
        ]
        optimal_tasks = [
            ['Complex problem solving', 'Strategic planning', 'Code reviews'],
            ['Development work', 'Important meetings', 'Design tasks'],
            ['Email processing', 'Team sync', 'Documentation'],
            ['Administrative tasks', 'Learning', 'Breaks']
        ]
        
        self.productivity_zones = {}
        for i, (cluster_id, _) in enumerate(sorted_clusters):
            self.productivity_zones[cluster_id] = {
                'zone_name': zone_names[i] if i < len(zone_names) else f'Zone {i}',
                'description': zone_descriptions[i] if i < len(zone_descriptions) else 'General productivity zone',
                'optimal_tasks': optimal_tasks[i] if i < len(optimal_tasks) else ['General tasks']
            }
    
    def _get_zone_info(self, cluster_id):
        """Get information about a productivity zone"""
        return self.productivity_zones.get(cluster_id, {
            'zone_name': 'Unknown Zone',
            'description': 'Productivity zone not defined',
            'optimal_tasks': ['General tasks']
        })
    
    def _get_optimal_scheduling_times(self, productivity_score, user_data):
        """Generate scheduling recommendations"""
        recommendations = []
        
        if productivity_score > 0.8:
            recommendations.append("Schedule important meetings and complex tasks")
            recommendations.append("Ideal for code reviews and strategic decisions")
        elif productivity_score > 0.6:
            recommendations.append("Good for focused development work")
            recommendations.append("Suitable for team collaboration")
        elif productivity_score > 0.4:
            recommendations.append("Schedule routine tasks and email processing")
            recommendations.append("Good for documentation and planning")
        else:
            recommendations.append("Consider scheduling breaks or learning time")
            recommendations.append("Best for administrative tasks")
        
        return recommendations
    
    def _generate_heatmap_data(self, predictions):
        """Generate heatmap visualization data"""
        heatmap_data = {}
        
        for pred in predictions:
            hour = pred['hour_of_day']
            productivity = pred['predicted_productivity']
            
            if hour not in heatmap_data:
                heatmap_data[hour] = []
            
            heatmap_data[hour].append({
                'productivity': productivity,
                'zone': pred['productivity_zone']
            })
        
        # Calculate averages for each hour
        for hour in heatmap_data:
            avg_productivity = np.mean([item['productivity'] for item in heatmap_data[hour]])
            heatmap_data[hour] = {
                'average_productivity': float(avg_productivity),
                'sample_count': len(heatmap_data[hour]),
                'dominant_zone': max(set([item['zone'] for item in heatmap_data[hour]]), 
                                   key=[item['zone'] for item in heatmap_data[hour]].count)
            }
        
        return heatmap_data
    
    def _identify_optimal_slots(self, heatmap_matrix, hours, days):
        """Identify optimal time slots from heatmap"""
        optimal_slots = []
        
        for day_idx, day_data in enumerate(heatmap_matrix):
            for hour_idx, productivity in enumerate(day_data):
                if productivity > 0.7:  # High productivity threshold
                    optimal_slots.append({
                        'day': days[day_idx],
                        'hour': hours[hour_idx],
                        'productivity': float(productivity),
                        'recommendation': 'Optimal for important tasks'
                    })
        
        # Sort by productivity
        optimal_slots.sort(key=lambda x: x['productivity'], reverse=True)
        
        return optimal_slots[:10]  # Top 10 optimal slots