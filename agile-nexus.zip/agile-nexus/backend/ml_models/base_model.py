from abc import ABC, abstractmethod
import pickle
import os
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class BaseMLModel(ABC):
    """Base class for all ML models"""
    
    def __init__(self, model_name):
        self.model_name = model_name
        self.model = None
        self.is_trained = False
        self.last_training = None
        self.model_path = f"data/{model_name}_model.pkl"
    
    @abstractmethod
    def prepare_features(self, data):
        """Prepare features for training/prediction"""
        pass
    
    @abstractmethod
    def train(self, training_data):
        """Train the model"""
        pass
    
    @abstractmethod
    def predict(self, input_data):
        """Make predictions"""
        pass
    
    def save_model(self):
        """Save trained model to disk"""
        try:
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            with open(self.model_path, 'wb') as f:
                pickle.dump({
                    'model': self.model,
                    'last_training': self.last_training,
                    'model_name': self.model_name
                }, f)
            logger.info(f"Model {self.model_name} saved to {self.model_path}")
        except Exception as e:
            logger.error(f"Failed to save model {self.model_name}: {e}")
    
    def load_model(self):
        """Load trained model from disk"""
        try:
            if os.path.exists(self.model_path):
                with open(self.model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    self.model = model_data['model']
                    self.last_training = model_data.get('last_training')
                    self.is_trained = True
                logger.info(f"Model {self.model_name} loaded from {self.model_path}")
                return True
        except Exception as e:
            logger.error(f"Failed to load model {self.model_name}: {e}")
        return False