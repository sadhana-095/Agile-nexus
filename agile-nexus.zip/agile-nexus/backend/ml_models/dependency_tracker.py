from .base_model import BaseMLModel
import numpy as np
import pandas as pd
import networkx as nx
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class DependencyTracker(BaseMLModel):
    """AI model to track dependencies and predict cascade delays using Graph Neural Networks approach"""
    
    def __init__(self, load_saved_model=False):  # ✅ Add parameter
        self.model_name = 'dependency_tracker'  # ✅ ADD THIS LINE
        self.dependency_graph = nx.DiGraph()
        self.node_embeddings = {}
        self.risk_predictor = None
        self.feature_scaler = StandardScaler()
        self.story_features = {}
        self.cascade_predictor = None
        self.is_trained = False  # ✅ Add this
        self.last_training = None  # ✅ Add this
        self.model = None  # ✅ Add this

        # ✅ Only load if explicitly requested
        if load_saved_model:
            self.load_model()
    def prepare_features(self, data):
        """Prepare features for training/prediction - Required by base class"""
        return self.prepare_dependency_data(data)
    
    def prepare_dependency_data(self, dependency_data):
        """Prepare dependency data for graph construction"""
        dependencies = []
        
        for dep in dependency_data:
            dependencies.append({
                'source': dep.get('source_story', f'STORY_{np.random.randint(1, 100)}'),
                'target': dep.get('dependent_story', f'STORY_{np.random.randint(1, 100)}'),
                'dependency_type': dep.get('dependency_type', 'blocks'),
                'risk_probability': dep.get('risk_probability', np.random.uniform(0.1, 0.9)),
                'cascade_impact': dep.get('cascade_impact', np.random.randint(1, 5))
            })
        
        return dependencies
    
    def build_dependency_graph(self, dependencies):
        """Build dependency graph from dependency data"""
        self.dependency_graph.clear()
        
        # Add nodes and edges
        for dep in dependencies:
            source = dep['source']
            target = dep['target']
            
            # Add nodes with attributes
            if not self.dependency_graph.has_node(source):
                self.dependency_graph.add_node(source, 
                    story_type='feature',
                    complexity=np.random.choice(['low', 'medium', 'high']),
                    team_assigned=f'team_{np.random.randint(1, 4)}',
                    estimated_hours=np.random.randint(8, 40)
                )
            
            if not self.dependency_graph.has_node(target):
                self.dependency_graph.add_node(target,
                    story_type='feature', 
                    complexity=np.random.choice(['low', 'medium', 'high']),
                    team_assigned=f'team_{np.random.randint(1, 4)}',
                    estimated_hours=np.random.randint(8, 40)
                )
            
            # Add edge with dependency information
            self.dependency_graph.add_edge(source, target,
                dependency_type=dep['dependency_type'],
                risk_probability=dep['risk_probability'],
                cascade_impact=dep['cascade_impact']
            )
        
        logger.info(f"Built dependency graph with {self.dependency_graph.number_of_nodes()} nodes and {self.dependency_graph.number_of_edges()} edges")
    
    def generate_node_embeddings(self):
        """Generate node embeddings using graph structure and features"""
        embeddings = {}
        
        for node in self.dependency_graph.nodes():
            node_data = self.dependency_graph.nodes[node]
            
            # Basic node features
            complexity_map = {'low': 1, 'medium': 2, 'high': 3}
            complexity = complexity_map.get(node_data.get('complexity', 'medium'), 2)
            estimated_hours = node_data.get('estimated_hours', 20)
            
            # Graph-based features
            in_degree = self.dependency_graph.in_degree(node)
            out_degree = self.dependency_graph.out_degree(node)
            
            # Centrality measures (simplified GNN approach)
            try:
                betweenness = nx.betweenness_centrality(self.dependency_graph).get(node, 0)
                closeness = nx.closeness_centrality(self.dependency_graph).get(node, 0)
                pagerank = nx.pagerank(self.dependency_graph).get(node, 0)
            except:
                betweenness, closeness, pagerank = 0, 0, 1/len(self.dependency_graph.nodes())
            
            # Create embedding vector
            embedding = [
                complexity,
                estimated_hours / 40.0,  # Normalized
                in_degree,
                out_degree,
                betweenness,
                closeness,
                pagerank
            ]
            
            embeddings[node] = np.array(embedding)
        
        self.node_embeddings = embeddings
        return embeddings
    
    def train(self, dependency_data):
        """Train the dependency tracking model"""
        logger.info("Training Dependency Tracker with Graph Neural Network approach")
        
        try:
            # Prepare and build graph
            dependencies = self.prepare_dependency_data(dependency_data)
            if len(dependencies) < 5:
                # Generate synthetic dependencies for training
                dependencies = self._generate_synthetic_dependencies(20)
            
            self.build_dependency_graph(dependencies)
            
            # Generate node embeddings
            embeddings = self.generate_node_embeddings()
            
            # Prepare training data for risk prediction
            X_risk, y_risk = self._prepare_risk_training_data(dependencies, embeddings)
            X_cascade, y_cascade = self._prepare_cascade_training_data(dependencies, embeddings)
            
            # Train risk predictor
            if len(X_risk) > 0:
                X_risk_scaled = self.feature_scaler.fit_transform(X_risk)
                X_train, X_test, y_train, y_test = train_test_split(
                    X_risk_scaled, y_risk, test_size=0.2, random_state=42
                )
                
                self.risk_predictor = RandomForestRegressor(
                    n_estimators=100,
                    max_depth=10,
                    random_state=42
                )
                self.risk_predictor.fit(X_train, y_train)
                
                # Evaluate
                y_pred = self.risk_predictor.predict(X_test)
                risk_mae = mean_absolute_error(y_test, y_pred)
                risk_r2 = r2_score(y_test, y_pred)
                
                # Train cascade predictor
                self.cascade_predictor = RandomForestRegressor(
                    n_estimators=100,
                    max_depth=8,
                    random_state=42
                )
                self.cascade_predictor.fit(X_train, y_cascade[:len(X_train)])
                
                # Calculate graph metrics
                avg_path_length = self._calculate_average_path_length()
                critical_path_length = self._find_critical_path_length()
                
                self.model = {
                    'risk_predictor': self.risk_predictor,
                    'cascade_predictor': self.cascade_predictor,
                    'feature_scaler': self.feature_scaler,
                    'dependency_graph': self.dependency_graph,
                    'node_embeddings': self.node_embeddings,
                    'risk_mae': risk_mae,
                    'risk_r2': risk_r2
                }
                
                self.is_trained = True
                self.last_training = datetime.now()
                
                logger.info(f"Training completed - Risk MAE: {risk_mae:.3f}, Risk R2: {risk_r2:.3f}")
                
                return {
                    'status': 'success',
                    'risk_mae': float(risk_mae),
                    'risk_r2': float(risk_r2),
                    'graph_nodes': self.dependency_graph.number_of_nodes(),
                    'graph_edges': self.dependency_graph.number_of_edges(),
                    'avg_path_length': float(avg_path_length),
                    'critical_path_length': int(critical_path_length),
                    'training_samples': len(X_risk)
                }
            else:
                return {'status': 'failed', 'error': 'Insufficient training data'}
                
        except Exception as e:
            logger.error(f"Training failed: {e}")
            return {'status': 'failed', 'error': str(e)}
    
    def predict(self, input_data):
        """Predict dependency risks and cascade impacts"""
        # ✅ CRITICAL FIX: If not trained, train on the input data itself
        if not self.is_trained or self.risk_predictor is None:
            logger.warning("Model not trained. Training on input data now...")
            training_result = self.train(input_data)
            if training_result.get('status') != 'success':
                return {'error': 'Model training failed. Cannot make predictions.'}
    
        try:
            # Prepare input dependencies
            dependencies = self.prepare_dependency_data(input_data)
            
            # Build temporary graph for prediction
            temp_graph = self.dependency_graph.copy()
            for dep in dependencies:
                if not temp_graph.has_edge(dep['source'], dep['target']):
                    temp_graph.add_edge(dep['source'], dep['target'],
                        dependency_type=dep['dependency_type'],
                        risk_probability=dep['risk_probability'],
                        cascade_impact=dep['cascade_impact']
                    )
            
            predictions = []
            
            for dep in dependencies:
                source = dep['source']
                target = dep['target']
                
                # Get or create embeddings for prediction
                source_embedding = self.node_embeddings.get(source, np.zeros(7))
                target_embedding = self.node_embeddings.get(target, np.zeros(7))
                
                # Create feature vector for prediction
                edge_features = [
                    dep['risk_probability'],
                    dep['cascade_impact'],
                    temp_graph.in_degree(target),
                    temp_graph.out_degree(source)
                ]
                
                feature_vector = np.concatenate([
                    source_embedding,
                    target_embedding, 
                    edge_features
                ]).reshape(1, -1)
                
                # ✅ FIX: Use the scaler that was fitted during training
                feature_scaled = self.feature_scaler.transform(feature_vector)
                
                predicted_risk = self.risk_predictor.predict(feature_scaled)[0]
                predicted_cascade = self.cascade_predictor.predict(feature_scaled)[0]
                
                # Analyze dependency path
                path_analysis = self._analyze_dependency_path(source, target, temp_graph)
                
                predictions.append({
                    'source_story': source,
                    'dependent_story': target,
                    'dependency_type': dep['dependency_type'],
                    'predicted_risk_probability': float(np.clip(predicted_risk, 0, 1)),
                    'predicted_cascade_impact': int(np.clip(predicted_cascade, 1, 10)),
                    'risk_category': self._categorize_risk(predicted_risk),
                    'path_analysis': path_analysis,
                    'recommendations': self._generate_dependency_recommendations(predicted_risk, predicted_cascade, path_analysis)
                })
            
            # Generate dependency network analysis
            network_analysis = self._analyze_dependency_network(temp_graph)
            
            return {
                'predictions': predictions,
                'network_analysis': network_analysis,
                'model_info': {
                    'last_training': self.last_training.isoformat() if self.last_training else None,
                    'graph_nodes': temp_graph.number_of_nodes(),
                    'graph_edges': temp_graph.number_of_edges()
                }
            }
            
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return {'error': str(e)}
    
    def get_dependency_visualization(self):
        """Generate data for dependency network visualization"""
        if not self.dependency_graph.nodes():
            return {'error': 'No dependency graph available'}
        
        try:
            # Prepare nodes for visualization
            nodes = []
            for node in self.dependency_graph.nodes():
                node_data = self.dependency_graph.nodes[node]
                embedding = self.node_embeddings.get(node, np.zeros(7))
                
                nodes.append({
                    'id': node,
                    'label': node,
                    'complexity': node_data.get('complexity', 'medium'),
                    'team_assigned': node_data.get('team_assigned', 'unknown'),
                    'estimated_hours': node_data.get('estimated_hours', 0),
                    'in_degree': self.dependency_graph.in_degree(node),
                    'out_degree': self.dependency_graph.out_degree(node),
                    'centrality_score': float(embedding[4]) if len(embedding) > 4 else 0
                })
            
            # Prepare edges for visualization
            edges = []
            for source, target, edge_data in self.dependency_graph.edges(data=True):
                edges.append({
                    'source': source,
                    'target': target,
                    'dependency_type': edge_data.get('dependency_type', 'blocks'),
                    'risk_probability': edge_data.get('risk_probability', 0.5),
                    'cascade_impact': edge_data.get('cascade_impact', 1)
                })
            
            # Identify critical paths
            critical_paths = self._find_critical_paths()
            
            return {
                'nodes': nodes,
                'edges': edges,
                'critical_paths': critical_paths,
                'graph_metrics': {
                    'total_nodes': len(nodes),
                    'total_edges': len(edges),
                    'avg_path_length': self._calculate_average_path_length(),
                    'density': nx.density(self.dependency_graph)
                }
            }
            
        except Exception as e:
            logger.error(f"Visualization generation failed: {e}")
            return {'error': str(e)}
    
    def _generate_synthetic_dependencies(self, n_dependencies=20):
        """Generate synthetic dependency data for training"""
        dependencies = []
        stories = [f'USER_STORY_{i:03d}' for i in range(1, 31)]
        
        for i in range(n_dependencies):
            source = np.random.choice(stories)
            target = np.random.choice([s for s in stories if s != source])
            
            dependencies.append({
                'source': source,
                'target': target,
                'dependency_type': np.random.choice(['blocks', 'relates', 'duplicates']),
                'risk_probability': np.random.uniform(0.1, 0.9),
                'cascade_impact': np.random.randint(1, 6)
            })
        
        return dependencies
    
    def _prepare_risk_training_data(self, dependencies, embeddings):
        """Prepare training data for risk prediction"""
        X, y = [], []
        
        for dep in dependencies:
            source_emb = embeddings.get(dep['source'], np.zeros(7))
            target_emb = embeddings.get(dep['target'], np.zeros(7))
            # ✅ FIX: Include in_degree and out_degree like in predict()
            source_node = dep['source']
            target_node = dep['target']
            in_degree = self.dependency_graph.in_degree(target_node) if self.dependency_graph.has_node(target_node) else 0
            out_degree = self.dependency_graph.out_degree(source_node) if self.dependency_graph.has_node(source_node) else 0
            features = np.concatenate([
                source_emb,
                target_emb,
                [dep['risk_probability'], dep['cascade_impact'], in_degree, out_degree]
            ])
            
            X.append(features)
            y.append(dep['risk_probability'])
        
        return np.array(X), np.array(y)
    
    def _prepare_cascade_training_data(self, dependencies, embeddings):
        """Prepare training data for cascade impact prediction"""
        X, y = [], []
        
        for dep in dependencies:
            source_emb = embeddings.get(dep['source'], np.zeros(7))
            target_emb = embeddings.get(dep['target'], np.zeros(7))
            # ✅ FIX: Include in_degree and out_degree
            source_node = dep['source']
            target_node = dep['target']
            in_degree = self.dependency_graph.in_degree(target_node) if self.dependency_graph.has_node(target_node) else 0
            out_degree = self.dependency_graph.out_degree(source_node) if self.dependency_graph.has_node(source_node) else 0
            features = np.concatenate([
                source_emb,
                target_emb,
                [dep['risk_probability'], dep['cascade_impact'], in_degree, out_degree]
            ])
            
            X.append(features)
            y.append(dep['cascade_impact'])
        
        return np.array(X), np.array(y)
    
    def _analyze_dependency_path(self, source, target, graph):
        """Analyze path between source and target"""
        try:
            if nx.has_path(graph, source, target):
                path = nx.shortest_path(graph, source, target)
                path_length = len(path) - 1
                
                # Calculate path risk
                path_risk = 0
                for i in range(len(path) - 1):
                    edge_data = graph.edges[path[i], path[i+1]]
                    path_risk += edge_data.get('risk_probability', 0.5)
                
                path_risk = path_risk / path_length if path_length > 0 else 0
                
                return {
                    'path_exists': True,
                    'path_length': path_length,
                    'path': path,
                    'path_risk': float(path_risk),
                    'is_critical_path': path_length > 3
                }
            else:
                return {
                    'path_exists': False,
                    'path_length': 0,
                    'path': [],
                    'path_risk': 0.0,
                    'is_critical_path': False
                }
        except:
            return {
                'path_exists': False,
                'path_length': 0,
                'path': [],
                'path_risk': 0.0,
                'is_critical_path': False
            }
    
    def _analyze_dependency_network(self, graph):
        """Analyze the overall dependency network"""
        try:
            # Basic metrics
            num_nodes = graph.number_of_nodes()
            num_edges = graph.number_of_edges()
            density = nx.density(graph) if num_nodes > 1 else 0
            
            # Identify bottlenecks (nodes with high in-degree)
            bottlenecks = []
            if num_nodes > 0:
                in_degrees = dict(graph.in_degree())
                avg_in_degree = sum(in_degrees.values()) / len(in_degrees)
                bottlenecks = [node for node, degree in in_degrees.items() 
                             if degree > avg_in_degree * 1.5]
            
            # Find strongly connected components
            try:
                scc_count = len(list(nx.strongly_connected_components(graph)))
            except:
                scc_count = num_nodes
            
            return {
                'total_dependencies': num_edges,
                'total_stories': num_nodes,
                'network_density': float(density),
                'bottleneck_stories': bottlenecks[:5],  # Top 5 bottlenecks
                'strongly_connected_components': scc_count,
                'complexity_assessment': self._assess_network_complexity(num_nodes, num_edges, density)
            }
        except Exception as e:
            logger.error(f"Network analysis failed: {e}")
            return {
                'total_dependencies': 0,
                'total_stories': 0,
                'network_density': 0.0,
                'bottleneck_stories': [],
                'strongly_connected_components': 0,
                'complexity_assessment': 'unknown'
            }
    
    def _calculate_average_path_length(self):
        """Calculate average path length in the graph"""
        try:
            if self.dependency_graph.number_of_nodes() > 1:
                return nx.average_shortest_path_length(self.dependency_graph)
            return 0.0
        except:
            return 0.0
    
    def _find_critical_path_length(self):
        """Find the longest path in the dependency graph"""
        try:
            if self.dependency_graph.number_of_nodes() == 0:
                return 0
            return max([len(nx.shortest_path(self.dependency_graph, source, target)) - 1
                       for source in self.dependency_graph.nodes()
                       for target in self.dependency_graph.nodes()
                       if nx.has_path(self.dependency_graph, source, target) and source != target])
        except:
            return 0
    
    def _find_critical_paths(self):
        """Find critical dependency paths"""
        critical_paths = []
        
        try:
            # Find longest paths
            for source in self.dependency_graph.nodes():
                for target in self.dependency_graph.nodes():
                    if source != target and nx.has_path(self.dependency_graph, source, target):
                        path = nx.shortest_path(self.dependency_graph, source, target)
                        if len(path) > 3:  # Critical if more than 3 nodes
                            critical_paths.append({
                                'path': path,
                                'length': len(path) - 1,
                                'source': source,
                                'target': target
                            })
            
            # Sort by length and return top 5
            critical_paths.sort(key=lambda x: x['length'], reverse=True)
            return critical_paths[:5]
        except:
            return []
    
    def _categorize_risk(self, risk_score):
        """Categorize risk level"""
        if risk_score < 0.3:
            return 'Low'
        elif risk_score < 0.6:
            return 'Medium'  
        elif risk_score < 0.8:
            return 'High'
        else:
            return 'Critical'
    
    def _assess_network_complexity(self, nodes, edges, density):
        """Assess network complexity"""
        if nodes < 5:
            return 'Simple'
        elif nodes < 15 and density < 0.3:
            return 'Moderate'
        elif density > 0.6:
            return 'Complex'
        else:
            return 'Moderate'
    
    def _generate_dependency_recommendations(self, risk, cascade_impact, path_analysis):
        """Generate recommendations for dependency management"""
        recommendations = []
        
        if risk > 0.8:
            recommendations.append("CRITICAL: Consider breaking this dependency")
            recommendations.append("Implement parallel development where possible")
        elif risk > 0.6:
            recommendations.append("HIGH RISK: Monitor closely and have contingency plans")
            recommendations.append("Consider adding buffer time to dependent stories")
        elif risk > 0.4:
            recommendations.append("MEDIUM RISK: Regular sync meetings recommended")
        else:
            recommendations.append("LOW RISK: Standard dependency management sufficient")
        
        if cascade_impact > 5:
            recommendations.append("High cascade impact - prioritize early completion")
        
        if path_analysis.get('is_critical_path', False):
            recommendations.append("On critical path - any delay will impact sprint timeline")
        
        return recommendations