import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def test_email():
    try:
        # Email settings
        smtp_server = "smtp.gmail.com"
        smtp_port = 587  # Using 587 with STARTTLS
        sender_email = "roobabaskaran194@gmail.com"
        sender_password = "pyfl xnrr bpfs svwh"
        recipient = "roobabaskaran194@gmail.com"
        
        # Create message
        msg = MIMEMultipart()
        msg['Subject'] = "Test Email"
        msg['From'] = sender_email
        msg['To'] = recipient
        msg.attach(MIMEText("This is a test email.", 'plain'))
        
        # Send
        print(f"Connecting to {smtp_server}:{smtp_port}...")
        server = smtplib.SMTP(smtp_server, smtp_port, timeout=10)
        server.set_debuglevel(1)  # Show detailed output
        server.ehlo()
        print("Starting TLS...")
        server.starttls()
        server.ehlo()
        print("Logging in...")
        server.login(sender_email, sender_password)
        print("Sending...")
        server.send_message(msg)
        server.quit()
        
        print("✅ Email sent successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_email()