"""
Simple GitHub connection test
"""
import os
from dotenv import load_dotenv

print("\n" + "="*60)
print("Testing GitHub Connection")
print("="*60)

# Load environment
load_dotenv()

github_token = os.getenv('GITHUB_TOKEN')

if not github_token:
    print("❌ GITHUB_TOKEN not found in environment!")
    print("\nCheck your .env file:")
    print("1. File exists in backend/ folder")
    print("2. Contains line: GITHUB_TOKEN=ghp_...")
    print("3. No extra spaces or quotes")
    exit(1)

print(f"✅ Token found: {github_token[:10]}...")

# Test connection
try:
    from github import Github
    
    print("\n1️⃣ Connecting to GitHub...")
    g = Github(github_token)
    
    print("2️⃣ Getting user info...")
    user = g.get_user()
    
    print(f"\n✅ SUCCESS!")
    print(f"   Connected as: {user.login}")
    print(f"   Name: {user.name or 'Not set'}")
    
    print("\n3️⃣ Checking repositories...")
    repos = list(user.get_repos())
    print(f"   Found: {len(repos)} repositories")
    
    if len(repos) > 0:
        print("\n   Your repositories:")
        for repo in repos[:5]:  # Show first 5
            print(f"   - {repo.name} ({repo.html_url})")
    
except Exception as e:
    print(f"\n❌ Connection failed: {e}")
    print("\nPossible fixes:")
    print("1. Check token has 'repo' permission")
    print("2. Token might be expired - regenerate it")
    print("3. Copy token carefully (no extra spaces)")