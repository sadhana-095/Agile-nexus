from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json
from werkzeug.security import generate_password_hash, check_password_hash
db = SQLAlchemy()


db = SQLAlchemy()
# ✅ ADD THIS NEW USER MODEL
class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(200), unique=True, nullable=False)
    password_hash = db.Column(db.String(500), nullable=False)
    full_name = db.Column(db.String(200))
    role = db.Column(db.String(50), default='member')  # 'manager' or 'member'
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if password matches"""
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'role': self.role,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
    
# Sprint Health Metrics (for Sprint Health Predictor)
class SprintHealthMetrics(db.Model):
    __tablename__ = 'sprint_health_metrics'
    
    id = db.Column(db.Integer, primary_key=True)
    sprint_id = db.Column(db.String(100), nullable=False)
    team_id = db.Column(db.String(100), nullable=False)
    
    # Calendar Density Analysis data
    calendar_density = db.Column(db.Float, default=0.0)
    meeting_hours = db.Column(db.Float, default=0.0)
    focus_time_hours = db.Column(db.Float, default=0.0)
    
    # Risk Prediction (0-100%)
    predicted_risk_score = db.Column(db.Float, default=0.0)
    risk_factors = db.Column(db.Text)  # JSON string
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# Productivity Patterns (for Productivity Heatmap AI)
class ProductivityPatterns(db.Model):
    __tablename__ = 'productivity_patterns'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)
    team_id = db.Column(db.String(100), nullable=False)
    
    # Time slots and productivity
    time_slot = db.Column(db.DateTime, nullable=False)
    productivity_score = db.Column(db.Float, default=0.0)  # 0-1 scale
    
    # Factors affecting productivity
    factors = db.Column(db.Text)  # JSON: meetings, interruptions, workload
    optimal_zone = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Dependency Tracking (for Graph Neural Networks)
class DependencyChains(db.Model):
    __tablename__ = 'dependency_chains'
    
    id = db.Column(db.Integer, primary_key=True)
    source_story = db.Column(db.String(200), nullable=False)
    dependent_story = db.Column(db.String(200), nullable=False)
    
    # Risk analysis
    risk_probability = db.Column(db.Float, default=0.0)
    cascade_impact = db.Column(db.Integer, default=0)  # How many stories affected
    
    # Sprint information
    source_sprint_id = db.Column(db.String(100))
    dependent_sprint_id = db.Column(db.String(100))
    
    # Status
    status = db.Column(db.String(50), default='active')  # active, resolved, blocked
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Team Calendar Data (from ETL Pipeline)
class CalendarData(db.Model):
    __tablename__ = 'calendar_data'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)
    event_id = db.Column(db.String(200), nullable=False)
    
    # Event details
    title = db.Column(db.String(500))
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    event_type = db.Column(db.String(100))  # meeting, focus, break
    
    # Analysis data
    attendee_count = db.Column(db.Integer, default=0)
    is_recurring = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # ✅ ADD THIS LINE:
    data_source = db.Column(db.String(20), default='mock')
    
# Communication Data (Slack/Teams from ETL)
class CommunicationData(db.Model):
    __tablename__ = 'communication_data'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)
    team_id = db.Column(db.String(100), nullable=False)
    
    # Communication metrics
    message_count = db.Column(db.Integer, default=0)
    response_time_avg = db.Column(db.Float, default=0.0)  # minutes
    active_hours = db.Column(db.Float, default=0.0)
    
    # Date for aggregation
    date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # ✅ ADD THIS LINE:
    data_source = db.Column(db.String(20), default='mock')
# Code Activity (GitHub/GitLab from ETL)
class CodeActivity(db.Model):
    __tablename__ = 'code_activity'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)
    repository = db.Column(db.String(200), nullable=False)
    
    # Code metrics
    commits_count = db.Column(db.Integer, default=0)
    lines_added = db.Column(db.Integer, default=0)
    lines_removed = db.Column(db.Integer, default=0)
    pull_requests = db.Column(db.Integer, default=0)
    
    # Date for aggregation
    date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # ✅ ADD THIS LINE:
    data_source = db.Column(db.String(20), default='mock')
# ✅ ADD THESE NEW MODELS FOR NOTIFICATIONS

class Notification(db.Model):
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    recipient_username = db.Column(db.String(100), db.ForeignKey('users.username'))
    title = db.Column(db.String(200))
    message = db.Column(db.Text)
    notification_type = db.Column(db.String(50))
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'recipient_username': self.recipient_username,
            'title': self.title,
            'message': self.message,
            'notification_type': self.notification_type,
            'is_read': self.is_read,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Project(db.Model):
    __tablename__ = 'projects'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    created_by = db.Column(db.String(100), db.ForeignKey('users.username'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(50), default='active')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'status': self.status
        }


class ProjectMember(db.Model):
    __tablename__ = 'project_members'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'))
    username = db.Column(db.String(100), db.ForeignKey('users.username'))
    role = db.Column(db.String(50), default='member')
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'project_id': self.project_id,
            'username': self.username,
            'role': self.role,
            'joined_at': self.joined_at.isoformat() if self.joined_at else None
        }

class RiskAlert(db.Model):
    __tablename__ = 'risk_alerts'
    
    id = db.Column(db.Integer, primary_key=True)
    alert_type = db.Column(db.String(50), nullable=False)  # 'sprint_risk', 'dependency_risk', 'capacity_risk'
    severity = db.Column(db.String(20), nullable=False)  # 'critical', 'high', 'medium', 'low'
    
    # Target
    target_user_id = db.Column(db.String(100))
    target_team_id = db.Column(db.String(100))
    target_sprint_id = db.Column(db.String(100))
    
    # Risk Details
    risk_score = db.Column(db.Float, default=0.0)
    risk_factors = db.Column(db.Text)  # JSON string
    recommendations = db.Column(db.Text)  # JSON string
    
    # Status
    status = db.Column(db.String(50), default='active')  # 'active', 'acknowledged', 'resolved'
    acknowledged_by = db.Column(db.String(100))
    acknowledged_at = db.Column(db.DateTime)
    resolved_at = db.Column(db.DateTime)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'alert_type': self.alert_type,
            'severity': self.severity,
            'target_user_id': self.target_user_id,
            'target_team_id': self.target_team_id,
            'target_sprint_id': self.target_sprint_id,
            'risk_score': self.risk_score,
            'risk_factors': json.loads(self.risk_factors) if self.risk_factors else [],
            'recommendations': json.loads(self.recommendations) if self.recommendations else [],
            'status': self.status,
            'acknowledged_by': self.acknowledged_by,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Task(db.Model):
    __tablename__ = 'tasks'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id'), nullable=True)  # ✅ ADD THIS LINE
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    assigned_to = db.Column(db.String(100), db.ForeignKey('users.username'), nullable=False)
    assigned_by = db.Column(db.String(100), db.ForeignKey('users.username'), nullable=False)
    status = db.Column(db.String(50), default='pending')  # pending, in_progress, completed
    priority = db.Column(db.String(20), default='medium')  # low, medium, high
    due_date = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completion_percentage = db.Column(db.Integer, default=0)  # 0-100

    # Relationships
    project = db.relationship('Project', backref='tasks')  # ✅ Add this
    assignee = db.relationship('User', foreign_keys=[assigned_to], backref='assigned_tasks')
    assigner = db.relationship('User', foreign_keys=[assigned_by], backref='created_tasks')
    
    def to_dict(self):
        return {
            'id': self.id,
            'project_id': self.project_id,  # ✅ ADD THIS
            'title': self.title,
            'description': self.description,
            'assigned_to': self.assigned_to,
            'assigned_by': self.assigned_by,
            'status': self.status,
            'priority': self.priority,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'completion_percentage': self.completion_percentage
        }

    