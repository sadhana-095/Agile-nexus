"""
Automatic Alert Generation Script
Run this periodically (e.g., every hour) to generate alerts based on current predictions
"""

from app import create_app
from notification_service import AutoAlertService
from ml_models.sprint_health_predictor import SprintHealthPredictor
from ml_models.dependency_tracker import DependencyTracker
from processing.processing_coordinator import ProcessingCoordinator

app = create_app()

def generate_all_alerts():
    """Generate all types of alerts"""
    with app.app_context():
        print("\n" + "="*70)
        print("🔔 AUTO-ALERT GENERATION")
        print("="*70)
        
        try:
            # Step 1: Run processing
            print("\n1️⃣ Running data processing...")
            processor = ProcessingCoordinator()
            processing_results = processor.run_full_processing(days_back=7)
            print("   ✅ Processing complete")
            
            # Step 2: Generate Sprint Health Alerts
            print("\n2️⃣ Analyzing sprint health...")
            sprint_features = processing_results.get('sample_sprint_features', [])
            
            if sprint_features:
                predictor = SprintHealthPredictor()
                predictions = predictor.predict(sprint_features)
                
                alerts_count = AutoAlertService.analyze_sprint_health_and_alert(
                    predictions.get('predictions', [])
                )
                print(f"   ✅ Generated {alerts_count} sprint risk alerts")
            else:
                print("   ⚠️ No sprint features available")
            
            # Step 3: Generate Dependency Alerts
            print("\n3️⃣ Analyzing dependencies...")
            dependency_features = processing_results.get('sample_dependency_features', [])
            
            if dependency_features:
                tracker = DependencyTracker()
                dep_predictions = tracker.predict(dependency_features)
                
                warnings_count = AutoAlertService.analyze_dependencies_and_alert(
                    dep_predictions.get('predictions', [])
                )
                print(f"   ✅ Generated {warnings_count} dependency warnings")
            else:
                print("   ⚠️ No dependency features available")
            
            print("\n" + "="*70)
            print("✅ AUTO-ALERT GENERATION COMPLETE!")
            print("="*70)
            
        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()

if __name__ == '__main__':
    generate_all_alerts()