import os
from dotenv import load_dotenv

print("Testing .env file loading...\n")

# Load .env
load_dotenv()

# Check each variable
github_token = os.getenv('GITHUB_TOKEN')
slack_token = os.getenv('SLACK_BOT_TOKEN')
db_url = os.getenv('DATABASE_URL')

print("GITHUB_TOKEN:", "✅ Found" if github_token else "❌ Not found")
if github_token:
    print(f"  Value: {github_token[:10]}... (showing first 10 chars)")

print("\nSLACK_BOT_TOKEN:", "✅ Found" if slack_token else "❌ Not found")
if slack_token:
    print(f"  Value: {slack_token[:10]}... (showing first 10 chars)")

print("\nDATABASE_URL:", "✅ Found" if db_url else "❌ Not found")
if db_url:
    print(f"  Value: {db_url[:30]}... (showing first 30 chars)")