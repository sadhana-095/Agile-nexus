"""
Debug GitHub data loading
"""
import os
from etl_pipeline.github_real import GitHubRealExtractor
from models import db, CodeActivity
from app import create_app

print("\n" + "="*60)
print("DEBUG: GitHub Data Loading")
print("="*60)

# Initialize app
app = create_app()

with app.app_context():
    # Extract GitHub data
    github_token = os.getenv('GITHUB_TOKEN')
    
    if not github_token:
        print("❌ GITHUB_TOKEN not found in environment!")
        exit(1)
    
    print(f"\n1️⃣ Extracting GitHub data for: Rooba8925")
    extractor = GitHubRealExtractor(github_token)
    activity = extractor.extract_user_activity('Rooba8925', days_back=365)
    
    print(f"   Extracted: {len(activity)} repositories")
    
    if len(activity) == 0:
        print("   ❌ No activity found!")
        exit(1)
    
    # Show extracted data
    print(f"\n2️⃣ Extracted Data:")
    for item in activity:
        print(f"   - {item['repository']}: {item['commits_count']} commits, +{item['lines_added']} lines")
    
    # Try to load into database
    print(f"\n3️⃣ Loading into database...")
    
    for code in activity:
        try:
            # Check if exists
            existing = CodeActivity.query.filter_by(
                user_id=code['user_id'],
                repository=code['repository'],
                date=code['date']
            ).first()
            
            if existing:
                print(f"   ⏭️ Already exists: {code['repository']}")
                continue
            
            # Create new record
            code_record = CodeActivity(
                user_id=code['user_id'],
                repository=code['repository'],
                commits_count=code['commits_count'],
                lines_added=code['lines_added'],
                lines_removed=code['lines_removed'],
                pull_requests=code['pull_requests'],
                date=code['date']
            )
            
            # Mark as real
            code_record.data_source = 'real'
            
            db.session.add(code_record)
            print(f"   ✅ Added: {code['repository']}")
            
        except Exception as e:
            print(f"   ❌ Error adding {code['repository']}: {e}")
    
    # Commit
    try:
        db.session.commit()
        print(f"\n✅ Commit successful!")
    except Exception as e:
        print(f"\n❌ Commit failed: {e}")
        db.session.rollback()
    
    # Verify
    print(f"\n4️⃣ Verifying database...")
    real_count = CodeActivity.query.filter_by(data_source='real').count()
    mock_count = CodeActivity.query.filter_by(data_source='mock').count()
    
    print(f"   Real data: {real_count}")
    print(f"   Mock data: {mock_count}")
    
    if real_count > 0:
        print(f"\n✅ SUCCESS! GitHub data is in database")
        
        real_records = CodeActivity.query.filter_by(data_source='real').all()
        for record in real_records:
            print(f"   - {record.repository}: {record.commits_count} commits")
    else:
        print(f"\n❌ FAILED! No real data in database")

print("\n" + "="*60)