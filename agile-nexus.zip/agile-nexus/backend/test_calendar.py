
from etl_pipeline.google_calendar_real import GoogleCalendarRealExtractor

extractor = GoogleCalendarRealExtractor()

print("\n" + "="*60)
print("Testing Google Calendar Extraction")
print("="*60)

events = extractor.extract_events(days_back=30, exclude_holidays=True)

print(f"\n✅ Total events found: {len(events)}\n")

if events:
    for i, event in enumerate(events, 1):
        print(f"{i}. {event['title']}")
        print(f"   📅 {event['start_time']}")
        print(f"   📚 {event.get('calendar_name', 'Unknown')}")
        print()
else:
    print("❌ No events found!")