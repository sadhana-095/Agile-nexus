import unittest
from datetime import datetime
from app import create_app
from models import db, SprintHealthMetrics, ProductivityPatterns, DependencyChains

class TestDatabase(unittest.TestCase):
    """Test database operations"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test database"""
        cls.app = create_app()
        cls.app.config['TESTING'] = True
        cls.app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:admin123@localhost/agile_nexus_test'
        
        with cls.app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test database"""
        with cls.app.app_context():
            db.drop_all()
    
    def setUp(self):
        """Set up before each test"""
        self.app_context = self.app.app_context()
        self.app_context.push()
    
    def tearDown(self):
        """Clean up after each test"""
        db.session.remove()
        self.app_context.pop()
    
    def test_sprint_health_metrics_creation(self):
        """Test creating sprint health metrics"""
        metric = SprintHealthMetrics(
            sprint_id='TEST_SPRINT_001',
            team_id='TEST_TEAM_01',
            calendar_density=0.7,
            meeting_hours=4.5,
            focus_time_hours=3.5,
            predicted_risk_score=35.0
        )
        
        db.session.add(metric)
        db.session.commit()
        
        retrieved = SprintHealthMetrics.query.filter_by(sprint_id='TEST_SPRINT_001').first()
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.team_id, 'TEST_TEAM_01')
        self.assertEqual(retrieved.predicted_risk_score, 35.0)
    
    def test_productivity_patterns_creation(self):
        """Test creating productivity patterns"""
        pattern = ProductivityPatterns(
            user_id='test_user',
            team_id='test_team',
            time_slot=datetime.now(),
            productivity_score=0.85
        )
        
        db.session.add(pattern)
        db.session.commit()
        
        retrieved = ProductivityPatterns.query.filter_by(user_id='test_user').first()
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.productivity_score, 0.85)
    
    def test_dependency_chains_creation(self):
        """Test creating dependency chains"""
        dependency = DependencyChains(
            source_story='STORY_001',
            dependent_story='STORY_002',
            risk_probability=0.7,
            cascade_impact=4
        )
        
        db.session.add(dependency)
        db.session.commit()
        
        retrieved = DependencyChains.query.filter_by(source_story='STORY_001').first()
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.cascade_impact, 4)

if __name__ == '__main__':
    unittest.main()