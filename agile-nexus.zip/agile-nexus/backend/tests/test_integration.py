import unittest
import json
from app import create_app
from models import db

class TestIntegration(unittest.TestCase):
    """Test full integration scenarios"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test app"""
        cls.app = create_app()
        cls.app.config['TESTING'] = True
        cls.client = cls.app.test_client()
        
        with cls.app.app_context():
            db.create_all()
    
    def test_full_pipeline_flow(self):
        """Test complete pipeline: ETL → Processing → Training → Prediction"""
        
        # Step 1: Run ETL
        response = self.client.get('/run-etl')
        self.assertEqual(response.status_code, 200)
        etl_data = json.loads(response.data)
        self.assertEqual(etl_data['status'], 'success')
        
        # Step 2: Run Processing
        response = self.client.get('/run-processing')
        self.assertEqual(response.status_code, 200)
        processing_data = json.loads(response.data)
        self.assertEqual(processing_data['status'], 'success')
        
        # Step 3: Train Models
        response = self.client.get('/train-all-models')
        self.assertEqual(response.status_code, 200)
        training_data = json.loads(response.data)
        self.assertEqual(training_data['status'], 'success')
        
        # Step 4: Make Predictions
        response = self.client.get('/predict-sprint-risk')
        self.assertEqual(response.status_code, 200)
        prediction_data = json.loads(response.data)
        self.assertEqual(prediction_data['status'], 'success')
    
    def test_all_models_integration(self):
        """Test all three models working together"""
        
        # Test Sprint Health
        response = self.client.get('/test-sprint-model')
        self.assertEqual(response.status_code, 200)
        sprint_data = json.loads(response.data)
        self.assertEqual(sprint_data['status'], 'success')
        
        # Test Productivity
        response = self.client.get('/test-productivity-model')
        self.assertEqual(response.status_code, 200)
        productivity_data = json.loads(response.data)
        self.assertEqual(productivity_data['status'], 'success')
        
        # Test Dependencies
        response = self.client.get('/test-dependency-model')
        self.assertEqual(response.status_code, 200)
        dependency_data = json.loads(response.data)
        self.assertEqual(dependency_data['status'], 'success')

if __name__ == '__main__':
    unittest.main()