import unittest
import json
from app import create_app
from models import db

class TestAPIEndpoints(unittest.TestCase):
    """Test all API endpoints"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test app"""
        cls.app = create_app()
        cls.app.config['TESTING'] = True
        cls.client = cls.app.test_client()
        
        with cls.app.app_context():
            db.create_all()
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after tests"""
        with cls.app.app_context():
            db.drop_all()
    
    def test_home_endpoint(self):
        """Test home endpoint returns 200"""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
        self.assertIn('Agile Nexus', data['message'])
    
    def test_api_status(self):
        """Test API status endpoint"""
        response = self.client.get('/api-status')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertIn('ai_models', data)
        self.assertEqual(data['status'], 'success')
    
    def test_health_check(self):
        """Test health check endpoint"""
        response = self.client.get('/health-check')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'healthy')
    
    def test_run_etl(self):
        """Test ETL pipeline endpoint"""
        response = self.client.get('/run-etl')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
        self.assertIn('results', data)
    
    def test_run_processing(self):
        """Test processing pipeline endpoint"""
        response = self.client.get('/run-processing')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
    
    def test_sprint_model(self):
        """Test sprint health model endpoint"""
        response = self.client.get('/test-sprint-model')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
        self.assertIn('training_result', data)
        self.assertIn('test_predictions', data)
    
    def test_productivity_model(self):
        """Test productivity model endpoint"""
        response = self.client.get('/test-productivity-model')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
    
    def test_dependency_model(self):
        """Test dependency tracker endpoint"""
        response = self.client.get('/test-dependency-model')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
    
    def test_train_all_models(self):
        """Test training all models"""
        response = self.client.get('/train-all-models')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')
        self.assertIn('training_results', data)
    
    def test_full_pipeline(self):
        """Test full pipeline endpoint"""
        response = self.client.get('/run-full-pipeline')
        self.assertEqual(response.status_code, 200)
        
        data = json.loads(response.data)
        self.assertEqual(data['status'], 'success')

if __name__ == '__main__':
    unittest.main()