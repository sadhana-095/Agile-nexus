"""
Test notification system
"""

from app import create_app
from notification_service import NotificationService, AutoAlertService

app = create_app()

with app.app_context():
    print("\n" + "="*70)
    print("TESTING NOTIFICATION SYSTEM")
    print("="*70)
    
    # Test 1: Create Risk Alert
    print("\n1️⃣ Creating risk alert...")
    alert = NotificationService.create_risk_alert(
        user_id='rooba',
        risk_score=75,
        risk_factors={'high_meetings': True, 'low_focus_time': True},
        recommendations=['Reduce meetings', 'Add focus time blocks'],
        sprint_id='SPRINT_001'
    )
    print(f"   ✅ Alert created: {alert['title']}")
    
    # Test 2: Create Dependency Warning
    print("\n2️⃣ Creating dependency warning...")
    warning = NotificationService.create_dependency_warning(
        user_id='praneeta',
        source_story='USER_STORY_001',
        dependent_story='USER_STORY_002',
        risk_probability=0.8,
        cascade_impact=5
    )
    print(f"   ✅ Warning created: {warning['title']}")
    
    # Test 3: Team Notification
    print("\n3️⃣ Broadcasting team notification...")
    notifications = NotificationService.create_team_notification(
        team_id='all',
        title='🚀 Sprint Planning Session',
        message='Sprint planning meeting scheduled for tomorrow at 10 AM',
        severity='info'
    )
    print(f"   ✅ Sent to {len(notifications)} team members")
    
    # Test 4: Get User Notifications
    print("\n4️⃣ Getting notifications for rooba...")
    user_notifications = NotificationService.get_user_notifications('rooba')
    print(f"   ✅ Found {len(user_notifications)} notifications")
    
    for notif in user_notifications[:3]:
        print(f"      - {notif['title']} ({notif['severity']})")
    
    print("\n" + "="*70)
    print("✅ NOTIFICATION SYSTEM TEST COMPLETE!")
    print("="*70)