import os
from dotenv import load_dotenv

load_dotenv()  # Load .env file

class Config:
    # Use postgres user directly (since you're learning locally)
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL','postgresql://postgres:admin123@localhost/agile_nexus')
    TIMESCALE_URI = os.getenv('TIMESCALE_URI','postgresql://postgres:admin123@localhost/agile_timeseries')
    
    # Redis (we'll install later)
    REDIS_URL = os.getenv('REDIS_URL','redis://localhost:6379')
    
    # API Keys (we'll set up later)
    GOOGLE_CALENDAR_API_KEY = ''
    GOOGLE_REDIRECT_URI = 'http://localhost:5000/manager-dashboard'
    SLACK_BOT_TOKEN = os.getenv('SLACK_BOT_TOKEN', 'xoxb-9678420409587-9684885300322-N42TzR5tH9tltoSVoZ6SoxrF')
    GITHUB_TOKEN = os.getenv('GITHUB_TOKEN', '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')
    
    # ML Model settings
    MODEL_UPDATE_INTERVAL =  int(os.getenv('MODEL_UPDATE_INTERVAL', 3600))  # 1 hour
    RISK_THRESHOLD = int(os.getenv('RISK_THRESHOLD', 70))  # Sprint failure risk threshold