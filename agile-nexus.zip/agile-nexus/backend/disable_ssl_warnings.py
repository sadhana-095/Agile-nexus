"""
Disable SSL verification warnings for development
WARNING: Only use this in development, never in production!
"""

import ssl
import urllib3
import warnings

def disable_ssl_verification():
    """Disable SSL verification for development"""
    # Disable urllib3 warnings
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
    # Disable SSL warnings
    warnings.filterwarnings('ignore', message='Unverified HTTPS request')
    
    print("⚠️  SSL verification disabled (development mode only)")

# Call this at startup
disable_ssl_verification()