from .base_extractor import BaseExtractor
from datetime import datetime, timedelta
import random
import json

class GoogleCalendarExtractor(BaseExtractor):
    """Extract data from Google Calendar (Mock data for learning)"""
    
    def __init__(self, config):
        super().__init__(config)
        self.users = ['user_001', 'user_002', 'user_003', 'user_004']
    
    def extract_data(self, start_date=None, end_date=None):
        """Extract calendar events (mock data for now)"""
        if not start_date or not end_date:
            start_date, end_date = self.get_date_range()
        
        calendar_events = []
        
        # Generate mock calendar data
        for user in self.users:
            events = self._generate_user_events(user, start_date, end_date)
            calendar_events.extend(events)
        
        self.log_extraction("Google Calendar", len(calendar_events))
        return calendar_events
    
    def _generate_user_events(self, user_id, start_date, end_date):
        """Generate realistic calendar events for a user"""
        events = []
        current_date = start_date
        
        while current_date <= end_date:
            # Skip weekends
            if current_date.weekday() < 5:  # Monday = 0, Friday = 4
                daily_events = self._create_daily_events(user_id, current_date)
                events.extend(daily_events)
            
            current_date += timedelta(days=1)
        
        return events
    
    def _create_daily_events(self, user_id, date):
        """Create realistic daily events"""
        events = []
        event_templates = [
            {"title": "Daily Standup", "duration": 0.5, "type": "meeting"},
            {"title": "Sprint Planning", "duration": 2.0, "type": "meeting"},
            {"title": "Code Review", "duration": 1.0, "type": "meeting"},
            {"title": "Focus Time - Development", "duration": 3.0, "type": "focus"},
            {"title": "Team Sync", "duration": 1.0, "type": "meeting"},
            {"title": "Client Demo", "duration": 1.5, "type": "meeting"},
        ]
        
        # Generate 3-6 events per day
        num_events = random.randint(3, 6)
        start_hour = 9
        
        for i in range(num_events):
            template = random.choice(event_templates)
            
            event_start = datetime.combine(date.date(), datetime.min.time()) + timedelta(hours=start_hour)
            event_end = event_start + timedelta(hours=template["duration"])
            
            events.append({
                "user_id": user_id,
                "event_id": f"cal_{user_id}_{date.strftime('%Y%m%d')}_{i}",
                "title": template["title"],
                "start_time": event_start,
                "end_time": event_end,
                "event_type": template["type"],
                "attendee_count": random.randint(2, 8) if template["type"] == "meeting" else 1,
                "is_recurring": random.choice([True, False])
            })
            
            start_hour += template["duration"] + 0.5  # 30 min gap
        
        return events