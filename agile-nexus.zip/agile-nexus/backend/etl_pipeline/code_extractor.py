from .base_extractor import BaseExtractor
from datetime import datetime, timedelta
import random

class CodeActivityExtractor(BaseExtractor):
    """Extract code activity from GitHub/GitLab (Mock data)"""
    
    def __init__(self, config):
        super().__init__(config)
        self.users = ['user_001', 'user_002', 'user_003', 'user_004']
        self.repositories = [
            'agile-nexus-frontend',
            'agile-nexus-backend', 
            'agile-nexus-ml-models',
            'agile-nexus-docs'
        ]
    
    def extract_data(self, start_date=None, end_date=None):
        """Extract code activity metrics"""
        if not start_date or not end_date:
            start_date, end_date = self.get_date_range()
        
        code_data = []
        current_date = start_date.date()
        
        while current_date <= end_date.date():
            # Skip weekends (developers usually don't code on weekends)
            if current_date.weekday() < 5:
                daily_data = self._generate_daily_activity(current_date)
                code_data.extend(daily_data)
            
            current_date += timedelta(days=1)
        
        self.log_extraction("GitHub/GitLab", len(code_data))
        return code_data
    
    def _generate_daily_activity(self, date_obj):
        """Generate daily code activity"""
        data = []
        
        for user in self.users:
            # Not every user commits every day
            if random.random() < 0.7:  # 70% chance of activity
                repo = random.choice(self.repositories)
                
                # Generate realistic code metrics
                commits = random.randint(0, 5)
                lines_added = commits * random.randint(10, 150) if commits > 0 else 0
                lines_removed = int(lines_added * random.uniform(0.1, 0.4)) if commits > 0 else 0
                pull_requests = 1 if commits > 2 and random.random() < 0.3 else 0
                
                data.append({
                    "user_id": user,
                    "repository": repo,
                    "commits_count": commits,
                    "lines_added": lines_added,
                    "lines_removed": lines_removed,
                    "pull_requests": pull_requests,
                    "date": date_obj
                })
        
        return data