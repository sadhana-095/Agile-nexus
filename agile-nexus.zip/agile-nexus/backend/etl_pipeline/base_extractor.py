from abc import ABC, abstractmethod
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class BaseExtractor(ABC):
    """Base class for all data extractors"""
    
    def __init__(self, config):
        self.config = config
        self.last_sync = None
    
    @abstractmethod
    def extract_data(self, start_date=None, end_date=None):
        """Extract data from source"""
        pass
    
    def get_date_range(self, days_back=7):
        """Get default date range for extraction"""
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days_back)
        return start_date, end_date
    
    def log_extraction(self, source, count):
        """Log extraction results"""
        logger.info(f"Extracted {count} records from {source}")