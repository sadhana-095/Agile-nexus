from .calendar_extractor import GoogleCalendarExtractor
from .communication_extractor import CommunicationExtractor
from .code_extractor import CodeActivityExtractor
from models import db, CalendarData, CommunicationData, CodeActivity
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class ETLCoordinator:
    """Coordinates all ETL processes"""
    
    def __init__(self, config):
        self.config = config
        self.extractors = {
            'calendar': GoogleCalendarExtractor(config),
            'communication': CommunicationExtractor(config),
            'code': CodeActivityExtractor(config)
        }
    
    def run_full_extraction(self, days_back=7):
        """Run all extractors and load data into database"""
        logger.info(f"Starting full ETL extraction for last {days_back} days")
        
        results = {}
        
        # Extract Calendar Data
        try:
            calendar_data = self.extractors['calendar'].extract_data()
            calendar_count = self._load_calendar_data(calendar_data)
            results['calendar'] = calendar_count
        except Exception as e:
            logger.error(f"Calendar extraction failed: {e}")
            results['calendar'] = 0
        
        # Extract Communication Data
        try:
            comm_data = self.extractors['communication'].extract_data()
            comm_count = self._load_communication_data(comm_data)
            results['communication'] = comm_count
        except Exception as e:
            logger.error(f"Communication extraction failed: {e}")
            results['communication'] = 0
        
        # Extract Code Data
        try:
            code_data = self.extractors['code'].extract_data()
            code_count = self._load_code_data(code_data)
            results['code'] = code_count
        except Exception as e:
            logger.error(f"Code extraction failed: {e}")
            results['code'] = 0
        
        logger.info(f"ETL completed: {results}")
        return results
    
    def _load_calendar_data(self, data):
        """Load calendar data into database"""
        count = 0
        for event in data:
            cal_record = CalendarData(
                user_id=event['user_id'],
                event_id=event['event_id'],
                title=event['title'],
                start_time=event['start_time'],
                end_time=event['end_time'],
                event_type=event['event_type'],
                attendee_count=event['attendee_count'],
                is_recurring=event['is_recurring']
            )
            db.session.add(cal_record)
            count += 1
        
        db.session.commit()
        return count
    
    def _load_communication_data(self, data):
        """Load communication data into database"""
        count = 0
        for comm in data:
            comm_record = CommunicationData(
                user_id=comm['user_id'],
                team_id=comm['team_id'],
                message_count=comm['message_count'],
                response_time_avg=comm['response_time_avg'],
                active_hours=comm['active_hours'],
                date=comm['date']
            )
            db.session.add(comm_record)
            count += 1
        
        db.session.commit()
        return count
    
    def _load_code_data(self, data):
        """Load code activity data into database"""
        count = 0
        for code in data:
            code_record = CodeActivity(
                user_id=code['user_id'],
                repository=code['repository'],
                commits_count=code['commits_count'],
                lines_added=code['lines_added'],
                lines_removed=code['lines_removed'],
                pull_requests=code['pull_requests'],
                date=code['date']
            )
            db.session.add(code_record)
            count += 1
        
        db.session.commit()
        return count