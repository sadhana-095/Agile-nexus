"""
Google Calendar Real Data Extractor - Query ALL Calendars
"""

import os
import pickle
import logging
from datetime import datetime, timedelta

# ✅ ADD THESE MISSING IMPORTS
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

logger = logging.getLogger(__name__)

class GoogleCalendarRealExtractor:
    """Extract real data from Google Calendar API"""
    
    SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']
    
    def __init__(self, credentials_file='credentials.json'):
        self.credentials_file = credentials_file
        self.service = None
        self.authenticate()
    
    # In your google_calendar_real.py, update the authenticate method:
    def authenticate(self):
        """Authenticate with Google Calendar API"""
        creds = None
    
        # Delete old token if it exists
        if os.path.exists('token.json'):
            try:
                creds = Credentials.from_authorized_user_file('token.json', self.SCOPES)
            except Exception as e:
                print(f"⚠️ Old token invalid: {e}")
                os.remove('token.json')
                creds = None
    
        # If no valid credentials, do OAuth flow
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                except Exception as e:
                    print(f"⚠️ Token refresh failed: {e}")
                    # ✅ USE FIXED PORT 8080 instead of port=0
                    flow = InstalledAppFlow.from_client_secrets_file('credentials.json', self.SCOPES)
                    creds = flow.run_local_server(port=8080)
            else:
                # ✅ USE FIXED PORT 8080 instead of port=0
                flow = InstalledAppFlow.from_client_secrets_file('credentials.json', self.SCOPES)
                creds = flow.run_local_server(port=8080)
        
            # Save credentials
            with open('token.json', 'w') as token:
                token.write(creds.to_json())
    
        self.service = build('calendar', 'v3', credentials=creds)
        print("✅ Google Calendar authenticated successfully")

    def extract_events(self, days_back=7, exclude_holidays=True):
        """Extract calendar events from ALL user calendars"""
        try:
            calendars = self.get_user_calendars()
            
            if exclude_holidays:
                calendars = [cal for cal in calendars 
                           if 'holiday' not in cal['summary'].lower()]
            
            # NEW - Much wider range to catch all events
            start_time = (datetime.utcnow() - timedelta(days=365)).isoformat() + 'Z'  # 1 year back
            end_time = (datetime.utcnow() + timedelta(days=365)).isoformat() + 'Z'    # 1 year forward
            
            
            logger.info(f"📅 Querying {len(calendars)} calendars")
            
            all_events = []
            
            for calendar in calendars:
                calendar_id = calendar['id']
                calendar_name = calendar['summary']
                
                try:
                    logger.info(f"  📚 {calendar_name}")
                    
                    events_result = self.service.events().list(
                        calendarId=calendar_id,
                        timeMin=start_time,
                        timeMax=end_time,
                        singleEvents=True,
                        orderBy='startTime',
                        maxResults=100
                    ).execute()
                    
                    events = events_result.get('items', [])
                    
                    for event in events:
                        start = event['start'].get('dateTime', event['start'].get('date'))
                        end = event['end'].get('dateTime', event['end'].get('date'))
                        title = event.get('summary', 'Untitled')
                        
                        # Skip holidays
                        if exclude_holidays:
                            holiday_keywords = ['holiday', 'diwali', 'christmas', 'new year']
                            if any(kw in title.lower() for kw in holiday_keywords):
                                continue
                        
                        logger.info(f"      ✅ {title}")
                        
                        all_events.append({
                            'user_id': calendar_id,
                            'event_id': event['id'],
                            'title': title,
                            'start_time': start,
                            'end_time': end,
                            'event_type': self._categorize_event(title),
                            'attendee_count': len(event.get('attendees', [])),
                            'is_recurring': 'recurringEventId' in event,
                            'description': event.get('description', ''),
                            'calendar_name': calendar_name
                        })
                        
                except Exception as e:
                    logger.warning(f"    ⚠️ Error: {e}")
            
            logger.info(f"✅ Extracted {len(all_events)} events")
            return all_events
            
        except Exception as e:
            logger.error(f"❌ Extraction failed: {e}")
            return []
    
    def _categorize_event(self, title):
        """Categorize event"""
        title_lower = title.lower()
        
        if any(w in title_lower for w in ['task', 'assignment', 'exam', 'test']):
            return 'focus'
        elif any(w in title_lower for w in ['break', 'lunch']):
            return 'break'
        else:
            return 'meeting'
    
    def get_user_calendars(self):
        """Get user's calendars"""
        try:
            calendars_result = self.service.calendarList().list().execute()
            calendars = calendars_result.get('items', [])
            
            return [{
                'id': cal['id'],
                'summary': cal.get('summary', 'Unknown'),
                'primary': cal.get('primary', False)
            } for cal in calendars]
        except Exception as e:
            logger.error(f"Error getting calendars: {e}")
            return []