"""
GitHub Real Data Extractor
Extracts real code activity from GitHub API
"""

import os
import logging
from datetime import datetime, timedelta
import re

logger = logging.getLogger(__name__)

class GitHubRealExtractor:
    """Extract real data from GitHub API"""
    
    def __init__(self):
        """Initialize GitHub connection using Personal Access Token"""
        self.logger = logging.getLogger(__name__)
    
        # ✅ ADD THIS: Disable SSL verification for GitHub API
        import ssl
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    
        try:
            token = os.getenv('GITHUB_TOKEN')
            if not token:
                raise ValueError("GITHUB_TOKEN not found in environment variables")
        
            # ✅ MODIFY THIS: Add verify=False for SSL bypass
            import requests
            from github import Github
        
            # Create a session that doesn't verify SSL
            session = requests.Session()
            session.verify = False
        
            # Use the session with PyGithub
            self.client = Github(token, per_page=100)
        
            # Test connection
            try:
                user = self.client.get_user()
                self.logger.info(f"✅ Connected to GitHub as {user.login}")
                self.authenticated = True
            except Exception as e:
                self.logger.error(f"❌ GitHub connection failed: {str(e)}")
                self.authenticated = False
            
        except Exception as e:
            self.logger.error(f"❌ GitHub initialization failed: {str(e)}")
            self.client = None
            self.authenticated = False
    
    def verify_connection(self):
        """Verify GitHub connection"""
        try:
            user = self.github.get_user()
            logger.info(f"✅ Connected to GitHub as {user.login}")
            return True
        except Exception as e:
            logger.error(f"❌ GitHub connection failed: {e}")
            return False
    
    def extract_github_dependencies(self, usernames):
        """
        Extract REAL dependencies from GitHub issues
        
        Args:
            usernames: List of GitHub usernames to analyze
            
        Returns:
            List of dependency dictionaries
        """
        dependencies = []
        
        for username in usernames:
            try:
                logger.info(f"🔍 Fetching dependencies for: {username}")
                
                # ✅ FIX: Get user object properly
                try:
                    user = self.github.get_user(username)
                    if not user:
                        logger.warning(f"❌ User {username} not found")
                        continue
                except Exception as e:
                    logger.warning(f"❌ Could not fetch user {username}: {e}")
                    continue
                
                # Get all repositories - with error handling
                try:
                    repos = list(user.get_repos())[:10]  # ✅ Limit to first 10 repos
                    logger.info(f"  📚 Found {len(repos)} repositories for {username}")
                except Exception as e:
                    logger.warning(f"  ❌ Could not fetch repos for {username}: {e}")
                    continue
                
                if not repos:
                    logger.info(f"  ℹ️ No repositories found for {username}")
                    continue
                
                for repo in repos:
                    try:
                        # Get all issues (including PRs)
                        issues = list(repo.get_issues(state='all'))[:20]  # ✅ Limit to 20 issues
                        
                        for issue in issues:
                            try:
                                # Look for dependency keywords in body and comments
                                body = issue.body or ""
                                
                                # Search for dependency patterns
                                dep_keywords = [
                                    'depends on', 'blocks', 'blocked by', 
                                    'requires', 'needs', 'waiting for',
                                    'prerequisite', 'dependent on'
                                ]
                                
                                for keyword in dep_keywords:
                                    if keyword.lower() in body.lower():
                                        # Extract referenced issue numbers
                                        issue_refs = re.findall(r'#(\d+)', body)
                                        
                                        for ref_num in issue_refs:
                                            try:
                                                ref_issue = repo.get_issue(int(ref_num))
                                                
                                                dependencies.append({
                                                    'source_story': f"{repo.name}#{issue.number}",
                                                    'source_task_name': issue.title,
                                                    'dependent_story': f"{repo.name}#{ref_issue.number}",
                                                    'dependent_task_name': ref_issue.title,
                                                    'dependency_type': keyword,
                                                    'user_id': username,
                                                    'repo': repo.name,
                                                    'source_url': issue.html_url,
                                                    'dependent_url': ref_issue.html_url,
                                                    'created_at': issue.created_at.isoformat(),
                                                    'source_state': issue.state,
                                                    'dependent_state': ref_issue.state
                                                })
                                                
                                                logger.info(f"      ✅ Found: {issue.title} -> {ref_issue.title}")
                                            except Exception as e:
                                                logger.debug(f"      Could not fetch issue #{ref_num}: {e}")
                                
                            except Exception as e:
                                logger.debug(f"    Error processing issue: {e}")
                                continue
                        
                    except Exception as e:
                        logger.debug(f"  Error processing repo {repo.name}: {e}")
                        continue
                
            except Exception as e:
                logger.error(f"❌ Error processing {username}: {e}")
                continue
        
        logger.info(f"✅ Extracted {len(dependencies)} dependencies total")
        return dependencies
    
    def extract_code_activity(self, username, days_back=7):
        """Extract code activity for a user"""
        try:
            user = self.github.get_user(username)
            if not user:
                return []
            
            activities = []
            since = datetime.utcnow() - timedelta(days=days_back)
            
            # Get user's repositories
            repos = list(user.get_repos())[:10]
            
            for repo in repos:
                try:
                    # Get commits by this user
                    commits = repo.get_commits(author=user, since=since)
                    
                    for commit in commits:
                        activities.append({
                            'user_id': username,
                            'repository': repo.full_name,
                            'commit_sha': commit.sha,
                            'commit_message': commit.commit.message,
                            'commit_date': commit.commit.author.date,
                            'files_changed': len(commit.files) if commit.files else 0,
                            'additions': sum(f.additions for f in commit.files) if commit.files else 0,
                            'deletions': sum(f.deletions for f in commit.files) if commit.files else 0
                        })
                except Exception as e:
                    logger.debug(f"Error fetching commits for {repo.name}: {e}")
                    continue
            
            return activities
            
        except Exception as e:
            logger.error(f"Error extracting code activity for {username}: {e}")
            return []