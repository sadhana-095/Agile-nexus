"""
Slack Real Data Extractor - FIXED VERSION
Properly counts messages from channels
"""

import os
import logging
from datetime import datetime, timedelta
import ssl
import certifi

logger = logging.getLogger(__name__)

class SlackRealExtractor:
    """Extract real data from Slack API"""
    
    def __init__(self, bot_token=None):
        # ✅ FIX: Store token as instance variable first
        self.token = token if token else os.getenv('SLACK_BOT_TOKEN')
        
        if not bot_token:
            bot_token = os.getenv('SLACK_BOT_TOKEN')
        
        if not bot_token:
            raise ValueError("SLACK_BOT_TOKEN environment variable not set")
        
        try:
            from slack_sdk import WebClient
            from slack_sdk.errors import SlackApiError
            
            # ✅ ADD SSL CONTEXT - Disable verification for development
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            self.client = WebClient(
                token=token,
                ssl=ssl_context  # ✅ Add this
            )
            self.client = WebClient(token=bot_token)
            self.SlackApiError = SlackApiError
            self.verify_connection()
            
        except ImportError:
            logger.error("❌ slack-sdk not installed. Run: pip install slack-sdk")
            raise
    
    def verify_connection(self):
        """Verify Slack connection"""
        try:
            response = self.client.auth_test()
            logger.info(f"✅ Connected to Slack as {response['user_id']}")
        except self.SlackApiError as e:
            logger.error(f"❌ Slack authentication failed: {e.response['error']}")
            raise
        except Exception as e:
            logger.error(f"❌ Slack connection error: {e}")
            raise
    
    def extract_team_activity(self, days_back=7):
        """Extract team communication metrics - FIXED VERSION"""
        try:
            team_data = []
            
            # Get all users
            users_result = self.client.users_list()
            users = users_result['members']
            
            # Get all channels the bot is in
            channels = self._get_bot_channels()
            
            if not channels:
                logger.warning("⚠️ Bot is not in any channels! Invite bot with: /invite @Agile Nexus Bot")
                return []
            
            logger.info(f"📊 Analyzing {len(channels)} channels...")
            
            # Calculate since timestamp
            since = int((datetime.now() - timedelta(days=days_back)).timestamp())
            
            for user in users:
                # Skip bots and deleted users
                if user.get('is_bot', False) or user['id'] == 'USLACKBOT' or user.get('deleted', False):
                    continue
                
                user_id = user['id']
                user_name = user.get('name', 'Unknown')
                real_name = user.get('real_name', user_name)
                
                try:
                    # Count messages across all channels
                    message_count = self._count_user_messages_from_channels(
                        user_id, 
                        channels, 
                        since
                    )
                    
                    # Calculate response time
                    response_time = self._calculate_response_time_from_channels(
                        user_id, 
                        channels, 
                        since
                    )
                    
                    # Calculate active hours
                    active_hours = self._calculate_active_hours_from_channels(
                        user_id, 
                        channels, 
                        since
                    )
                    
                    team_data.append({
                        'user_id': user_id,
                        'user_name': user_name,
                        'real_name': real_name,
                        'message_count': message_count,
                        'response_time_avg': response_time,
                        'active_hours': active_hours,
                        'date': datetime.now().date(),
                        'status': user.get('profile', {}).get('status_text', ''),
                        'email': user.get('profile', {}).get('email', '')
                    })
                    
                    logger.info(f"  ✅ {real_name}: {message_count} messages")
                    
                except Exception as e:
                    logger.warning(f"  ⚠️ Could not extract data for {user_name}: {e}")
            
            logger.info(f"✅ Extracted data for {len(team_data)} Slack users")
            return team_data
            
        except Exception as e:
            logger.error(f"❌ Error extracting Slack data: {e}")
            return []
    
    def _get_bot_channels(self):
        """Get all channels the bot is a member of"""
        try:
            response = self.client.conversations_list(
                types='public_channel,private_channel',
                limit=100
            )
            
            channels = []
            for channel in response.get('channels', []):
                # Check if bot is member
                if channel.get('is_member', False):
                    channels.append(channel)
            
            logger.info(f"📢 Bot is in {len(channels)} channels")
            for ch in channels:
                logger.info(f"  - #{ch['name']}")
            
            return channels
            
        except Exception as e:
            logger.error(f"Error getting channels: {e}")
            return []
    
    def _count_user_messages_from_channels(self, user_id, channels, since):
        """Count messages from a user across all channels"""
        total_count = 0
        
        for channel in channels:
            try:
                # Get channel history
                response = self.client.conversations_history(
                    channel=channel['id'],
                    oldest=str(since),
                    limit=1000  # Max allowed
                )
                
                messages = response.get('messages', [])
                
                # Count user's messages
                user_messages = [msg for msg in messages if msg.get('user') == user_id]
                total_count += len(user_messages)
                
            except Exception as e:
                logger.debug(f"Could not read {channel['name']}: {e}")
                continue
        
        return total_count
    
    def _calculate_response_time_from_channels(self, user_id, channels, since):
        """Calculate average response time"""
        try:
            response_times = []
            
            for channel in channels[:3]:  # Check first 3 channels
                try:
                    messages = self.client.conversations_history(
                        channel=channel['id'],
                        oldest=str(since),
                        limit=50
                    ).get('messages', [])
                    
                    # Reverse to chronological order
                    messages = list(reversed(messages))
                    
                    for i in range(len(messages) - 1):
                        curr_msg = messages[i]
                        next_msg = messages[i + 1]
                        
                        # If user responded to someone else
                        if (curr_msg.get('user') != user_id and 
                            next_msg.get('user') == user_id):
                            
                            time_diff = float(next_msg['ts']) - float(curr_msg['ts'])
                            response_times.append(time_diff / 60)  # Convert to minutes
                    
                except Exception:
                    continue
            
            if response_times:
                avg = sum(response_times) / len(response_times)
                return round(avg, 2)
            else:
                return 15.0  # Default
                
        except Exception:
            return 15.0
    
    def _calculate_active_hours_from_channels(self, user_id, channels, since):
        """Calculate active hours based on message timestamps"""
        try:
            active_hours = set()
            
            for channel in channels:
                try:
                    messages = self.client.conversations_history(
                        channel=channel['id'],
                        oldest=str(since),
                        limit=100
                    ).get('messages', [])
                    
                    for msg in messages:
                        if msg.get('user') == user_id and 'ts' in msg:
                            msg_time = datetime.fromtimestamp(float(msg['ts']))
                            active_hours.add(msg_time.hour)
                    
                except Exception:
                    continue
            
            if active_hours:
                # Estimate: each active hour = 0.75 hours of work
                estimated_hours = len(active_hours) * 0.75
                return round(min(12, max(1, estimated_hours)), 1)
            else:
                return 7.5  # Default
                
        except Exception:
            return 7.5
    
    def get_channels(self):
        """Get list of channels bot has access to"""
        try:
            response = self.client.conversations_list(
                types='public_channel,private_channel',
                limit=100
            )
            
            channels = response.get('channels', [])
            
            return [{
                'id': ch['id'],
                'name': ch['name'],
                'is_member': ch.get('is_member', False),
                'num_members': ch.get('num_members', 0),
                'topic': ch.get('topic', {}).get('value', ''),
                'purpose': ch.get('purpose', {}).get('value', '')
            } for ch in channels]
            
        except Exception as e:
            logger.error(f"Error getting channels: {e}")
            return []