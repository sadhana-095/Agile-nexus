"""
Real API Coordinator - FIXED VERSION
"""

import os
import logging
from datetime import datetime, timedelta
import re  # ✅ Add this import

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RealAPICoordinator:
    """Coordinates extraction from real APIs"""
    
    def __init__(self):
        self.calendar_extractor = None
        self.slack_extractor = None
        self.github_extractor = None
        self.initialize_extractors()
    
    def initialize_extractors(self):
        """Initialize all API extractors"""
        try:
            if os.path.exists('credentials.json'):
                try:
                    from flask import has_request_context
                    # ✅ PREVENT OAuth during web requests
                    if has_request_context():
                        logger.info("⏸️ Skipping Calendar init during web request (prevents OAuth popup)")
                        self.calendar_extractor = None
                    else:
                        from .google_calendar_real import GoogleCalendarRealExtractor
                        self.calendar_extractor = GoogleCalendarRealExtractor()
                        logger.info("✅ Google Calendar initialized")
                except Exception as e:
                    logger.warning(f"⚠️ Google Calendar init failed: {e}")
                    self.calendar_extractor = None
            else:
                logger.warning("⚠️ credentials.json not found")
                self.calendar_extractor = None
            slack_token = os.getenv('SLACK_BOT_TOKEN')

            if slack_token:
                try:
                    from .slack_real import SlackRealExtractor
                    self.slack_extractor = SlackRealExtractor(slack_token)
                    logger.info("✅ Slack initialized")
                except Exception as e:
                    logger.warning(f"⚠️ Slack init failed: {e}")
                    self.slack_extractor = None
            else:
                self.slack_extractor = None
            
            github_token = os.getenv('GITHUB_TOKEN')
            if github_token:
                try:
                    from .github_real import GitHubRealExtractor
                    self.github_extractor = GitHubRealExtractor(github_token)
                    logger.info("✅ GitHub initialized")
                except Exception as e:
                    logger.warning(f"⚠ GitHub init failed: {e}")
                    self.github_extractor = None
            else:
                self.github_extractor = None
                    
        except Exception as e:
            logger.warning(f"Some APIs not initialized: {e}")
    
    def run_real_extraction(self, days_back=7, github_usernames=None):
        """Run extraction from all available real APIs"""
        results = {
            'calendar': 0,
            'communication': 0,
            'code': 0,
            'calendar_total_in_db': 0,
            'status': 'success',
            'errors': []
        }
        
        logger.info("=" * 50)
        logger.info("Starting Real API Extraction")
        logger.info("=" * 50)
        
        # Extract Calendar Data
        if self.calendar_extractor:
            try:
                logger.info("Extracting Google Calendar data...")
                events = self.calendar_extractor.extract_events(days_back)
                count = self._load_calendar_data(events)
                results['calendar'] = count
                
                from models import CalendarData
                total_in_db = CalendarData.query.count()
                results['calendar_total_in_db'] = total_in_db
                
                logger.info(f"✅ Loaded {count} NEW events")
                logger.info(f"📊 Total in DB: {total_in_db}")
            except Exception as e:
                error_msg = f"Calendar extraction failed: {str(e)}"
                logger.error(f"❌ {error_msg}")
                results['errors'].append(error_msg)
        else:
            logger.info("⏭ Google Calendar not configured")
        
        # Slack and GitHub (keeping existing code)
        if self.slack_extractor:
            try:
                comm_data = self.slack_extractor.extract_team_activity(days_back)
                count = self._load_communication_data(comm_data)
                results['communication'] = count
            except Exception as e:
                results['errors'].append(f"Slack failed: {e}")
        
        if self.github_extractor and github_usernames:
            try:
                total_count = 0
                for username in github_usernames:
                    activity = self.github_extractor.extract_user_activity(username, days_back)
                    count = self._load_code_data(activity)
                    total_count += count
                results['code'] = total_count
            except Exception as e:
                results['errors'].append(f"GitHub failed: {e}")
        
        results['status'] = 'success' if not results['errors'] else 'partial'
        
        logger.info("=" * 50)
        logger.info(f"Extraction Complete - Status: {results['status']}")
        logger.info("=" * 50)
        
        return results
    
    
    def _load_calendar_data(self, events):
        """Load calendar data into database - FIXED"""
        from models import db, CalendarData
        from dateutil import parser
        
        count = 0
        skipped = 0
        
        if not events:
            logger.warning("⚠ No events to load")
            return 0
        
        logger.info(f"📥 Processing {len(events)} events...")
        
        for event in events:
            try:
                # Parse datetime
                start_time = event['start_time']
                end_time = event['end_time']
                
                if isinstance(start_time, str):
                    start_time = parser.isoparse(start_time)
                    end_time = parser.isoparse(end_time)
                
                # Check duplicates
                existing = CalendarData.query.filter_by(
                    event_id=str(event['event_id'])
                ).first()
                
                if existing:
                    logger.info(f"  ⏭ Skip: {event['title']}")
                    skipped += 1
                    continue
                
                # Create record
                cal_record = CalendarData(
                    user_id=str(event['user_id']),
                    event_id=str(event['event_id']),
                    title=str(event['title'])[:500],
                    start_time=start_time,
                    end_time=end_time,
                    event_type=str(event['event_type'])[:100],
                    attendee_count=int(event.get('attendee_count', 0)),
                    is_recurring=bool(event.get('is_recurring', False))
                )
                # ✅ ADD THIS LINE:
                cal_record.data_source = 'real'
                
                db.session.add(cal_record)
                count += 1
                logger.info(f"  ✅ Added: {event['title']}")
                
            except Exception as e:
                logger.error(f"  ❌ Error: {e}")
        
        # Commit
        try:
            db.session.commit()
            logger.info(f"✅ Committed {count} NEW, Skipped {skipped}")
            return count
        except Exception as e:
            logger.error(f"❌ Commit failed: {e}")
            db.session.rollback()
            return 0
    
    
    def _load_communication_data(self, comm_data):
        """Load communication data into database"""
        from models import db, CommunicationData
    
        count_new = 0
        count_updated = 0
    
        if not comm_data:
            logger.warning("⚠ No communication data to load")
            return 0
    
        logger.info(f"📥 Processing {len(comm_data)} Slack records...")
    
        for comm in comm_data:
            try:
                # Check for duplicates
                existing = CommunicationData.query.filter_by(
                    user_id=comm['user_id'],
                    date=comm['date']
                ).first()
            
                if existing:
                    # ✅ UPDATE existing record
                    existing.message_count = comm['message_count']
                    existing.response_time_avg = comm['response_time_avg']
                    existing.active_hours = comm['active_hours']
                    count_updated += 1
                    logger.info(f"   🔄 Updated: {comm.get('user_name', comm['user_id'])} - {comm['message_count']} messages")
                else:
                    # ✅ CREATE new record
                    comm_record = CommunicationData(
                        user_id=comm['user_id'],
                        team_id='slack',
                        message_count=comm['message_count'],
                        response_time_avg=comm['response_time_avg'],
                        active_hours=comm['active_hours'],
                        date=comm['date']
                    )
                    comm_record.data_source = 'real'
                    db.session.add(comm_record)
                    count_new += 1
                    logger.info(f"   ✅ Added: {comm.get('user_name', comm['user_id'])} - {comm['message_count']} messages")
            except Exception as e:
                logger.warning(f"  ❌ Error: {e}")
    
        try:
            db.session.commit()
            logger.info(f"✅ Committed {count} Slack records")
            return count
        except Exception as e:
            logger.error(f"❌ Commit failed: {e}")
            db.session.rollback()
            return 0
            
    def _load_code_data(self, code_data):
        """Load code activity data into database - PREVENT DUPLICATES"""
        from models import db, CodeActivity
        from datetime import datetime
    
        count_new = 0
        count_updated = 0
        skipped = 0
    
        if not code_data:
            logger.warning("⚠ No code data to load")
            return 0
    
        logger.info(f"📥 Processing {len(code_data)} GitHub records...")
    
        for code in code_data:
            try:
                # Parse date
                code_date = code['date']
                if isinstance(code_date, str):
                    from dateutil import parser
                    code_date = parser.parse(code_date).date()
                elif isinstance(code_date, datetime):
                    code_date = code_date.date()
            
                # ✅ STRONG DUPLICATE CHECK - Check by user_id + repository ONLY
                # (not by date, so same repo won't be added multiple times)
                existing = CodeActivity.query.filter_by(
                    user_id=code['user_id'],
                    repository=code['repository']
                ).first()
            
                if existing:
                    # ✅ UPDATE existing record with latest data
                    existing.commits_count = code['commits_count']
                    existing.lines_added = code['lines_added']
                    existing.lines_removed = code['lines_removed']
                    existing.pull_requests = code['pull_requests']
                    existing.date = code_date
                
                    logger.info(f"   🔄 Updated: {code['repository']} for {code['user_id']}")
                    count_updated += 1
                else:
                    # ✅ CREATE new record
                    code_record = CodeActivity(
                        user_id=code['user_id'],
                        repository=code['repository'],
                        commits_count=code['commits_count'],
                        lines_added=code['lines_added'],
                        lines_removed=code['lines_removed'],
                        pull_requests=code['pull_requests'],
                        date=code_date
                    )
                    code_record.data_source = 'real'
                
                    db.session.add(code_record)
                    count_new += 1
                    logger.info(f"   ✅ Added: {code['repository']} for {code['user_id']}")
            
            except Exception as e:
                logger.warning(f"   ❌ Error: {e}")
                import traceback
                traceback.print_exc()
    
        # Commit all changes
        try:
            db.session.commit()
            logger.info(f"✅ Committed {count_new} NEW, {count_updated} UPDATED")
            return count_new + count_updated
        except Exception as e:
            logger.error(f"❌ Commit failed: {e}")
            db.session.rollback()
            return 0
    
    def get_api_status(self):
        """Get status of all APIs"""
        return {
            'google_calendar': self.calendar_extractor is not None,
            'slack': self.slack_extractor is not None,
            'github': self.github_extractor is not None
        }

    def extract_github_dependencies(self, github_usernames, days_back=90):
        """Extract REAL dependency relationships from GitHub issues and PRs"""
        if not self.github_extractor:
            logger.warning("⚠️ GitHub not configured - cannot extract dependencies")
            return []

        # ✅ Smart detection of GitHub client attribute
        github_client = None
        if hasattr(self.github_extractor, 'github_client'):
            github_client = self.github_extractor.github_client
        elif hasattr(self.github_extractor, 'client'):
            github_client = self.github_extractor.client
        elif hasattr(self.github_extractor, 'github'):
            github_client = self.github_extractor.github
        elif hasattr(self.github_extractor, 'g'):
            github_client = self.github_extractor.g
        else:
            logger.error("❌ Cannot find GitHub client attribute in GitHubRealExtractor")
            return []

        all_dependencies = []
    
        logger.info("="*60)
        logger.info("🔗 EXTRACTING REAL GITHUB DEPENDENCIES")
        logger.info("="*60)
    
        for username in github_usernames:
            logger.info(f"\n👤 Processing dependencies for: {username}")
        
            try:
                # Get user's repositories
                user = self.github_extractor.github.get_user(username)
                repos = user.get_repos()
            
                repo_count = 0
                for repo in list(repos)[:10]:  # Check first 10 repos
                    repo_name = repo.full_name
                    logger.info(f"\n  📦 Checking repo: {repo_name}")
                
                    # ========== METHOD 1: Issues with dependency keywords ==========
                    try:
                        issues = repo.get_issues(state='all')
                        issue_count = 0
                    
                        for issue in list(issues)[:50]:  # Check first 50 issues
                            body = (issue.body or '').lower()
                            title = issue.title
                            issue_num = issue.number
                        
                            # Look for dependency keywords
                            if any(keyword in body for keyword in [
                                'depends on', 'blocked by', 'blocks', 
                                'requires', 'waiting for', 'prerequisite',
                                'dependency', 'blocker'
                            ]):
                                # Extract referenced issue numbers (#123)
                                import re
                                referenced_issues = re.findall(r'#(\d+)', body)
                            
                                for ref_num in referenced_issues:
                                    all_dependencies.append({
                                        'source_story': f"{username}_{repo.name}_issue_{ref_num}",
                                        'dependent_story': f"{username}_{repo.name}_issue_{issue_num}",
                                        'source_task_name': f"Issue #{ref_num}",
                                        'dependent_task_name': title[:50],
                                        'dependency_type': 'blocks',
                                        'risk_probability': 0.7,
                                        'cascade_impact': 3,
                                        'repository': repo_name,
                                        'source_url': f"https://github.com/{repo_name}/issues/{ref_num}",
                                        'dependent_url': issue.html_url
                                    })
                                    issue_count += 1
                                    logger.info(f"    ✅ Found: Issue #{ref_num} blocks Issue #{issue_num}")
                    
                        if issue_count > 0:
                            logger.info(f"  📊 Total issue dependencies: {issue_count}")
                        
                    except Exception as e:
                        logger.warning(f"  ⚠️ Issue extraction error: {e}")
                
                    # ========== METHOD 2: Pull Requests waiting for review ==========
                    try:
                        prs = repo.get_pulls(state='open')
                        pr_count = 0
                    
                        for pr in list(prs)[:20]:  # Check first 20 PRs
                            pr_num = pr.number
                            pr_title = pr.title
                        
                            # Check if PR has requested reviewers
                            requested_reviewers = pr.requested_reviewers
                            reviews = pr.get_reviews()
                            review_list = list(reviews)
                        
                            # If has requested reviewers but no approvals
                            if len(requested_reviewers) > 0:
                                approved = any(r.state == 'APPROVED' for r in review_list)
                            
                                if not approved:
                                    all_dependencies.append({
                                        'source_story': f"{username}_{repo.name}_pr_{pr_num}_review",
                                        'dependent_story': f"{username}_{repo.name}_pr_{pr_num}",
                                        'source_task_name': f"Code Review for PR #{pr_num}",
                                        'dependent_task_name': pr_title[:50],
                                        'dependency_type': 'blocks',
                                        'risk_probability': 0.6 if len(requested_reviewers) > 2 else 0.4,
                                        'cascade_impact': len(requested_reviewers),
                                        'repository': repo_name,
                                        'source_url': pr.html_url,
                                        'dependent_url': pr.html_url
                                    })
                                    pr_count += 1
                                    logger.info(f"    ✅ PR #{pr_num} blocked by {len(requested_reviewers)} reviews")
                        
                            # Check if PR has merge conflicts
                            if pr.mergeable is False:
                                all_dependencies.append({
                                    'source_story': f"{username}_{repo.name}_pr_{pr_num}_conflicts",
                                    'dependent_story': f"{username}_{repo.name}_pr_{pr_num}",
                                    'source_task_name': f"Resolve Conflicts for PR #{pr_num}",
                                    'dependent_task_name': pr_title[:50],
                                    'dependency_type': 'blocks',
                                    'risk_probability': 0.8,
                                    'cascade_impact': 4,
                                    'repository': repo_name,
                                    'source_url': pr.html_url,
                                    'dependent_url': pr.html_url
                                })
                                pr_count += 1
                                logger.info(f"    ✅ PR #{pr_num} blocked by merge conflicts")
                    
                        if pr_count > 0:
                            logger.info(f"  📊 Total PR dependencies: {pr_count}")
                        
                    except Exception as e:
                        logger.warning(f"  ⚠️ PR extraction error: {e}")
                
                    repo_count += 1
                    if repo_count >= 10:
                        break
        
            except Exception as e:
                logger.error(f"❌ Error processing {username}: {e}")
                import traceback
                logger.error(traceback.format_exc())
    
        logger.info(f"\n{'='*60}")
        logger.info(f"✅ TOTAL DEPENDENCIES EXTRACTED: {len(all_dependencies)}")
        logger.info(f"{'='*60}\n")
    
        return all_dependencies