from .base_extractor import BaseExtractor
from datetime import datetime, timedelta, date
import random

class CommunicationExtractor(BaseExtractor):
    """Extract communication data from Slack/Teams (Mock data)"""
    
    def __init__(self, config):
        super().__init__(config)
        self.users = ['user_001', 'user_002', 'user_003', 'user_004']
        self.teams = ['DEV_TEAM_01', 'QA_TEAM_01', 'DESIGN_TEAM_01']
    
    def extract_data(self, start_date=None, end_date=None):
        """Extract communication metrics"""
        if not start_date or not end_date:
            start_date, end_date = self.get_date_range()
        
        communication_data = []
        current_date = start_date.date()
        
        while current_date <= end_date.date():
            # Skip weekends
            if current_date.weekday() < 5:
                daily_data = self._generate_daily_communication(current_date)
                communication_data.extend(daily_data)
            
            current_date += timedelta(days=1)
        
        self.log_extraction("Slack/Teams", len(communication_data))
        return communication_data
    
    def _generate_daily_communication(self, date_obj):
        """Generate daily communication metrics"""
        data = []
        
        for user in self.users:
            team = random.choice(self.teams)
            
            # Generate realistic communication patterns
            base_messages = random.randint(15, 45)
            
            # Monday and Friday usually have more messages
            if date_obj.weekday() in [0, 4]:  # Monday, Friday
                message_count = int(base_messages * 1.3)
            else:
                message_count = base_messages
            
            data.append({
                "user_id": user,
                "team_id": team,
                "message_count": message_count,
                "response_time_avg": round(random.uniform(5.0, 25.0), 2),  # minutes
                "active_hours": round(random.uniform(6.5, 9.0), 2),  # hours
                "date": date_obj
            })
        
        return data