"""
Add unique constraint to prevent duplicate user+repo combinations
"""
from app import create_app
from models import db
from sqlalchemy import text

app = create_app()

with app.app_context():
    print("\n" + "="*70)
    print("ADDING UNIQUE CONSTRAINT TO CODE_ACTIVITY TABLE")
    print("="*70)
    
    try:
        # Check if constraint already exists
        result = db.session.execute(text("""
            SELECT constraint_name 
            FROM information_schema.table_constraints 
            WHERE table_name = 'code_activity' 
            AND constraint_type = 'UNIQUE'
        """))
        
        existing_constraints = [row[0] for row in result]
        print(f"\n📋 Existing constraints: {existing_constraints}")
        
        if 'unique_user_repo' in existing_constraints:
            print("✅ Unique constraint already exists!")
        else:
            # Add unique constraint
            print("\n➕ Adding unique constraint...")
            db.session.execute(text("""
                ALTER TABLE code_activity 
                ADD CONSTRAINT unique_user_repo 
                UNIQUE (user_id, repository)
            """))
            db.session.commit()
            print("✅ Unique constraint added successfully!")
        
        print("\n" + "="*70)
        print("✅ DATABASE CONSTRAINT CONFIGURED")
        print("="*70)
        
    except Exception as e:
        print(f"❌ Error: {e}")
        db.session.rollback()
        
        if "already exists" in str(e).lower():
            print("✅ Constraint already exists (that's good!)")
        else:
            print("\n⚠️ Could not add constraint. Manual SQL:")
            print("Run in PostgreSQL:")
            print("   ALTER TABLE code_activity ADD CONSTRAINT unique_user_repo UNIQUE (user_id, repository);")