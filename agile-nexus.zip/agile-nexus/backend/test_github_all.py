"""
Test GitHub extraction and show what's in database
"""
import os
from dotenv import load_dotenv
from etl_pipeline.github_real import GitHubRealExtractor
from app import create_app
from models import CodeActivity

load_dotenv()

print("\n" + "="*60)
print("GITHUB DATA: API vs DATABASE")
print("="*60)

# Test API extraction
github_token = os.getenv('GITHUB_TOKEN')
if not github_token:
    print("❌ GITHUB_TOKEN not found!")
    exit(1)

print("\n1️⃣ EXTRACTING FROM GITHUB API:")
extractor = GitHubRealExtractor(github_token)

# Your GitHub usernames
usernames = ['Rooba8925', 'praneetaAD078', 'sadhana-095']

for username in usernames:
    print(f"\n👤 {username}:")
    activity = extractor.extract_user_activity(username, days_back=365)
    print(f"   Found {len(activity)} repositories from API")
    
    for repo in activity:
        print(f"   - {repo['repository']}: {repo['commits_count']} commits, +{repo['lines_added']} lines")

# Check database
print("\n2️⃣ WHAT'S IN DATABASE:")
app = create_app()
with app.app_context():
    for username in usernames:
        print(f"\n👤 {username}:")
        records = CodeActivity.query.filter_by(user_id=username, data_source='real').all()
        print(f"   {len(records)} repositories in database")
        
        for record in records:
            print(f"   - {record.repository}: {record.commits_count} commits, +{record.lines_added} lines")

print("\n" + "="*60)