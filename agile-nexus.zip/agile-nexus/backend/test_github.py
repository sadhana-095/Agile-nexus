from etl_pipeline.github_real import GitHubRealExtractor
from dotenv import load_dotenv
import os
load_dotenv()
github_token = os.getenv('GITHUB_TOKEN')

if not github_token:
    print("❌ GITHUB_TOKEN not found!")
    exit(1)

print("\n" + "="*60)
print("Testing GitHub API Connection")
print("="*60)

try:
    extractor = GitHubRealExtractor(github_token)
    print("✅ GitHub connection successful!")
    
    # Extract activity - CHANGED TO 365 DAYS
    print("\nExtracting activity for: Rooba8925 (last 365 days)")
    activity = extractor.extract_user_activity('Rooba8925', days_back=365)
    print(f"\n✅ Found activity in {len(activity)} repositories\n")
    if len(activity) == 0:
        print("⚠️ No commits found in last 365 days")
        print("\nTip: Make a test commit to see activity:")
        print("  cd ~/projects")
        print("  echo '# Test' >> README.md")
        print("  git add . && git commit -m 'test' && git push")
    else:
        for repo in activity:
            print(f"📦 {repo['repository']}")
            print(f"   Commits: {repo['commits_count']}")
            print(f"   Lines Added: {repo['lines_added']}")
            print(f"   Lines Removed: {repo['lines_removed']}")
            print(f"   Pull Requests: {repo['pull_requests']}")
            print(f"   URL: {repo['url']}")
            print()
        
    print("\nExtracting activity for: sadhana-095 (last 365 days)")
    activity = extractor.extract_user_activity('sadhana-095', days_back=365)
    print(f"\n✅ Found activity in {len(activity)} repositories\n")
    if len(activity) == 0:
        print("⚠️ No commits found in last 365 days")
        print("\nTip: Make a test commit to see activity:")
        print("  cd ~/projects")
        print("  echo '# Test' >> README.md")
        print("  git add . && git commit -m 'test' && git push")
    else:
        for repo in activity:
            print(f"📦 {repo['repository']}")
            print(f"   Commits: {repo['commits_count']}")
            print(f"   Lines Added: {repo['lines_added']}")
            print(f"   Lines Removed: {repo['lines_removed']}")
            print(f"   Pull Requests: {repo['pull_requests']}")
            print(f"   URL: {repo['url']}")
            print()
        
    print("\nExtracting activity for: praneetaAD078 (last 365 days)")
    activity = extractor.extract_user_activity('praneetaAD078', days_back=365)
    print(f"\n✅ Found activity in {len(activity)} repositories\n")
    if len(activity) == 0:
        print("⚠️ No commits found in last 365 days")
        print("\nTip: Make a test commit to see activity:")
        print("  cd ~/projects")
        print("  echo '# Test' >> README.md")
        print("  git add . && git commit -m 'test' && git push")
    else:
        for repo in activity:
            print(f"📦 {repo['repository']}")
            print(f"   Commits: {repo['commits_count']}")
            print(f"   Lines Added: {repo['lines_added']}")
            print(f"   Lines Removed: {repo['lines_removed']}")
            print(f"   Pull Requests: {repo['pull_requests']}")
            print(f"   URL: {repo['url']}")
            print()
        
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()