"""
Remove duplicate GitHub repositories from database
Keep only the latest entry for each user+repo combination
"""
from app import create_app
from models import db, CodeActivity
from sqlalchemy import func

app = create_app()

with app.app_context():
    print("\n" + "="*70)
    print("CLEANING UP DUPLICATE GITHUB REPOSITORIES")
    print("="*70)
    
    # Find duplicates
    print("\n1️⃣ Finding duplicates...")
    
    # Group by user_id and repository to find duplicates
    duplicates = db.session.query(
        CodeActivity.user_id,
        CodeActivity.repository,
        func.count(CodeActivity.id).label('count')
    ).group_by(
        CodeActivity.user_id,
        CodeActivity.repository
    ).having(
        func.count(CodeActivity.id) > 1
    ).all()
    
    print(f"   Found {len(duplicates)} duplicate repository entries")
    
    if len(duplicates) == 0:
        print("   ✅ No duplicates found!")
        exit(0)
    
    # Remove duplicates
    print("\n2️⃣ Removing duplicates...")
    total_deleted = 0
    
    for user_id, repository, count in duplicates:
        print(f"\n   📦 {repository} (user: {user_id})")
        print(f"      Found {count} duplicate entries")
        
        # Get all entries for this user+repo
        entries = CodeActivity.query.filter_by(
            user_id=user_id,
            repository=repository
        ).order_by(CodeActivity.created_at.desc()).all()
        
        # Keep the first (most recent), delete the rest
        keep = entries[0]
        delete = entries[1:]
        
        print(f"      Keeping: ID={keep.id}, Commits={keep.commits_count}, Created={keep.created_at}")
        
        for entry in delete:
            print(f"      Deleting: ID={entry.id}, Commits={entry.commits_count}, Created={entry.created_at}")
            db.session.delete(entry)
            total_deleted += 1
    
    # Commit changes
    print(f"\n3️⃣ Committing changes...")
    db.session.commit()
    print(f"   ✅ Deleted {total_deleted} duplicate entries")
    
    # Verify
    print("\n4️⃣ Verification:")
    print("="*70)
    
    github_users = ['Rooba8925', 'praneetaAD078', 'sadhana-095']
    
    for username in github_users:
        repos = CodeActivity.query.filter_by(user_id=username).all()
        print(f"\n👤 {username}:")
        print(f"   Unique Repositories: {len(repos)}")
        
        for repo in repos:
            print(f"   - {repo.repository}: {repo.commits_count} commits")
    
    print("\n" + "="*70)
    print("✅ CLEANUP COMPLETE!")
    print("="*70)