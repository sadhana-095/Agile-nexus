import psycopg2
from config import Config

def test_database_connection():
    try:
        # Try with agile_user
        conn = psycopg2.connect(Config.SQLALCHEMY_DATABASE_URI)
        cursor = conn.cursor()
        cursor.execute("SELECT version();")
        version = cursor.fetchone()
        print(f"✅ Connected with agile_user: {version[0]}")
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"❌ agile_user failed: {e}")
        try:
            # Try with postgres user
            conn = psycopg2.connect(Config.POSTGRES_URI)
            cursor = conn.cursor()
            cursor.execute("SELECT version();")
            version = cursor.fetchone()
            print(f"✅ Connected with postgres user: {version[0]}")
            cursor.close()
            conn.close()
            return True
        except Exception as e2:
            print(f"❌ Both connections failed: {e2}")
            return False

if __name__ == "__main__":
    test_database_connection()