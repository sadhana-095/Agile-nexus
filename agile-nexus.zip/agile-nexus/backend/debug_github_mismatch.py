"""
Debug GitHub repo count mismatch
"""
import os
from dotenv import load_dotenv
from etl_pipeline.github_real import GitHubRealExtractor
from app import create_app
from models import CodeActivity

load_dotenv()

print("\n" + "="*70)
print("DEBUGGING GITHUB REPO COUNT MISMATCH")
print("="*70)

github_token = os.getenv('GITHUB_TOKEN')
if not github_token:
    print("❌ GITHUB_TOKEN not found!")
    exit(1)

extractor = GitHubRealExtractor(github_token)

# All teammates
usernames = ['Rooba8925', 'praneetaAD078', 'sadhana-095']

app = create_app()

with app.app_context():
    for username in usernames:
        print(f"\n{'='*70}")
        print(f"👤 {username}")
        print('='*70)
        
        # What GitHub API returns
        print("\n📡 FROM GITHUB API:")
        activity = extractor.extract_user_activity(username, days_back=365)
        print(f"   Total repos returned: {len(activity)}")
        
        if len(activity) > 0:
            for i, repo in enumerate(activity, 1):
                print(f"   {i}. {repo['repository']}")
                print(f"      - Commits: {repo['commits_count']}")
                print(f"      - Lines: +{repo['lines_added']} -{repo['lines_removed']}")
                print(f"      - Date: {repo['date']}")
        
        # What's in database
        print("\n💾 IN DATABASE:")
        db_records = CodeActivity.query.filter_by(user_id=username).all()
        print(f"   Total repos in DB: {len(db_records)}")
        
        if len(db_records) > 0:
            for i, record in enumerate(db_records, 1):
                print(f"   {i}. {record.repository}")
                print(f"      - Commits: {record.commits_count}")
                print(f"      - Lines: +{record.lines_added} -{record.lines_removed}")
                print(f"      - Date: {record.date}")
                print(f"      - Data Source: {record.data_source}")
        
        # Compare
        print(f"\n📊 COMPARISON:")
        api_repos = set(r['repository'] for r in activity)
        db_repos = set(r.repository for r in db_records)
        
        missing_in_db = api_repos - db_repos
        extra_in_db = db_repos - api_repos
        
        if missing_in_db:
            print(f"   ⚠️ Repos in API but NOT in DB: {missing_in_db}")
        if extra_in_db:
            print(f"   ⚠️ Repos in DB but NOT in API: {extra_in_db}")
        if not missing_in_db and not extra_in_db:
            print(f"   ✅ Perfect match!")
        
        print()

print("="*70)