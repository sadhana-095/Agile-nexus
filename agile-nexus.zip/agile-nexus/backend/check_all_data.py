import psycopg2
from config import Config

def check_all_data():
    """Check mock vs real data across all tables"""
    
    try:
        # Connect to database
        conn = psycopg2.connect(Config.SQLALCHEMY_DATABASE_URI)
        cursor = conn.cursor()
        
        print("\n" + "="*70)
        print("AGILE NEXUS - DATA SUMMARY (Mock vs Real)")
        print("="*70)
        
        # Calendar Data
        print("\n📅 CALENDAR DATA:")
        cursor.execute("""
            SELECT data_source, COUNT(*) 
            FROM calendar_data 
            GROUP BY data_source
        """)
        for row in cursor.fetchall():
            print(f"  {row[0]:10} | {row[1]:5} events")
        
        # Communication Data
        print("\n💬 COMMUNICATION DATA:")
        cursor.execute("""
            SELECT data_source, COUNT(*) 
            FROM communication_data 
            GROUP BY data_source
        """)
        for row in cursor.fetchall():
            print(f"  {row[0]:10} | {row[1]:5} records")
        
        # Code Activity
        print("\n💻 CODE ACTIVITY:")
        cursor.execute("""
            SELECT data_source, COUNT(*) 
            FROM code_activity 
            GROUP BY data_source
        """)
        for row in cursor.fetchall():
            print(f"  {row[0]:10} | {row[1]:5} commits")
        
        # Total Summary
        print("\n" + "="*70)
        print("TOTAL SUMMARY:")
        print("="*70)
        
        cursor.execute("""
            SELECT 
                (SELECT COUNT(*) FROM calendar_data WHERE data_source='real') as real_cal,
                (SELECT COUNT(*) FROM calendar_data WHERE data_source='mock') as mock_cal,
                (SELECT COUNT(*) FROM communication_data WHERE data_source='real') as real_comm,
                (SELECT COUNT(*) FROM communication_data WHERE data_source='mock') as mock_comm,
                (SELECT COUNT(*) FROM code_activity WHERE data_source='real') as real_code,
                (SELECT COUNT(*) FROM code_activity WHERE data_source='mock') as mock_code
        """)
        
        result = cursor.fetchone()
        
        print(f"\n📊 REAL DATA:")
        print(f"  Calendar:       {result[0]:5} events")
        print(f"  Communication:  {result[2]:5} records")
        print(f"  Code Activity:  {result[4]:5} commits")
        print(f"  TOTAL REAL:     {result[0] + result[2] + result[4]:5}")
        
        print(f"\n📦 MOCK DATA:")
        print(f"  Calendar:       {result[1]:5} events")
        print(f"  Communication:  {result[3]:5} records")
        print(f"  Code Activity:  {result[5]:5} commits")
        print(f"  TOTAL MOCK:     {result[1] + result[3] + result[5]:5}")
        
        print(f"\n🎯 GRAND TOTAL:   {sum(result):5}")
        
        print("\n" + "="*70)
        
        # Sample Real Data
        print("\n📋 SAMPLE REAL DATA:")
        print("="*70)
        
        # Real Calendar Events
        print("\n📅 Recent Calendar Events (Real):")
        cursor.execute("""
            SELECT title, start_time, user_id 
            FROM calendar_data 
            WHERE data_source='real' 
            ORDER BY start_time DESC 
            LIMIT 5
        """)
        for i, row in enumerate(cursor.fetchall(), 1):
            print(f"  {i}. {row[0]}")
            print(f"     {row[1]} | {row[2]}")
        
        # Real Slack Messages
        print("\n💬 Recent Communication (Real):")
        cursor.execute("""
            SELECT user_id, message_count, active_hours, date 
            FROM communication_data 
            WHERE data_source='real' 
            ORDER BY date DESC 
            LIMIT 3
        """)
        for i, row in enumerate(cursor.fetchall(), 1):
            print(f"  {i}. {row[0]}: {row[1]} messages, {row[2]} hours active ({row[3]})")
        
        # Real GitHub Activity
        print("\n💻 Recent Code Activity (Real):")
        cursor.execute("""
            SELECT user_id, repository, commits_count, lines_added, date 
            FROM code_activity 
            WHERE data_source='real' 
            ORDER BY date DESC 
            LIMIT 5
        """)
        for i, row in enumerate(cursor.fetchall(), 1):
            print(f"  {i}. {row[0]}/{row[1]}")
            print(f"     {row[2]} commits, +{row[3]} lines ({row[4]})")
        
        print("\n" + "="*70)
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    check_all_data()