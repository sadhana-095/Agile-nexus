import os
from dotenv import load_dotenv

print("\n" + "="*60)
print("Verifying .env File")
print("="*60)

# Load .env
load_dotenv()

# Check each variable
variables = {
    'SLACK_BOT_TOKEN': 'Slack Bot Token',
    'GITHUB_TOKEN': 'GitHub Token',
    'DATABASE_URL': 'Database URL'
}

all_good = True
for var_name, display_name in variables.items():
    value = os.getenv(var_name)
    if value:
        # Show first 10 chars only for security
        preview = value[:10] + "..." if len(value) > 10 else value
        print(f"✅ {display_name}: {preview}")
    else:
        print(f"❌ {display_name}: NOT FOUND")
        all_good = False

print("\n" + "="*60)
if all_good:
    print("✅ All environment variables configured!")
else:
    print("❌ Some environment variables missing!")
print("="*60)