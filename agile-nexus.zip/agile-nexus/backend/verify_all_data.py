"""
Verify all teammates' data in database
"""
from app import create_app
from models import CalendarData, CommunicationData, CodeActivity

app = create_app()

with app.app_context():
    print("\n" + "="*60)
    print("TEAMMATES DATA VERIFICATION")
    print("="*60)
    
    # Calendar Data
    print("\n📅 CALENDAR DATA:")
    print(f"   Real events: {CalendarData.query.filter_by(data_source='real').count()}")
    print(f"   Mock events: {CalendarData.query.filter_by(data_source='mock').count()}")
    print(f"   Total: {CalendarData.query.count()}")
    
    # Show unique calendar IDs (teammates)
    print("\n   Calendars:")
    calendars = CalendarData.query.filter_by(data_source='real').with_entities(CalendarData.user_id).distinct().all()
    for cal in calendars:
        count = CalendarData.query.filter_by(user_id=cal.user_id, data_source='real').count()
        print(f"   - {cal.user_id[:30]}... ({count} events)")
    
    # Communication Data
    print("\n💬 COMMUNICATION DATA (Slack):")
    print(f"   Real records: {CommunicationData.query.filter_by(data_source='real').count()}")
    print(f"   Mock records: {CommunicationData.query.filter_by(data_source='mock').count()}")
    print(f"   Total: {CommunicationData.query.count()}")
    
    # Show team members
    print("\n   Team Members:")
    users = CommunicationData.query.filter_by(data_source='real').with_entities(CommunicationData.user_id).distinct().all()
    for user in users:
        records = CommunicationData.query.filter_by(user_id=user.user_id, data_source='real').all()
        if records:
            total_msgs = sum(r.message_count for r in records)
            print(f"   - {user.user_id} ({total_msgs} total messages)")
    
    # Code Activity
    print("\n💻 CODE ACTIVITY (GitHub):")
    print(f"   Real records: {CodeActivity.query.filter_by(data_source='real').count()}")
    print(f"   Mock records: {CodeActivity.query.filter_by(data_source='mock').count()}")
    print(f"   Total: {CodeActivity.query.count()}")
    
    # Show developers
    print("\n   Developers:")
    devs = CodeActivity.query.filter_by(data_source='real').with_entities(CodeActivity.user_id).distinct().all()
    for dev in devs:
        repos = CodeActivity.query.filter_by(user_id=dev.user_id, data_source='real').all()
        total_commits = sum(r.commits_count for r in repos)
        total_lines = sum(r.lines_added for r in repos)
        print(f"   - {dev.user_id} ({len(repos)} repos, {total_commits} commits, +{total_lines} lines)")
    
    print("\n" + "="*60)