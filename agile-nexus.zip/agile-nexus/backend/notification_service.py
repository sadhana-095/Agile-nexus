"""
Notification Service for Agile Nexus
Handles risk alerts, team notifications, and dependency warnings
"""

from models import db, Notification, RiskAlert, User
from datetime import datetime
import json
import logging

logger = logging.getLogger(__name__)


class NotificationService:
    """Service for creating and managing notifications"""
    
    @staticmethod
    def create_risk_alert(user_id, risk_score, risk_factors, recommendations, sprint_id=None):
        """Create a risk alert notification"""
        try:
            # Determine severity
            if risk_score >= 70:
                severity = 'critical'
                title = '🚨 Critical Sprint Risk Alert'
            elif risk_score >= 50:
                severity = 'high'
                title = '⚠️ High Sprint Risk Detected'
            elif risk_score >= 25:
                severity = 'medium'
                title = '⚡ Moderate Sprint Risk'
            else:
                severity = 'low'
                title = '✓ Sprint Health Check'
            
            # Create message
            message = f"Your sprint risk score is {risk_score:.0f}%. "
            if risk_score >= 70:
                message += "Immediate action required to prevent sprint failure."
            elif risk_score >= 50:
                message += "Consider reducing meeting load and adding focus time."
            else:
                message += "Keep monitoring your calendar density and focus time."
            
            # Create notification
            notification = Notification(
                user_id=user_id,
                notification_type='risk_alert',
                severity=severity,
                title=title,
                message=message,
                related_sprint_id=sprint_id
            )
            db.session.add(notification)
            
            # Create risk alert record
            alert = RiskAlert(
                alert_type='sprint_risk',
                severity=severity,
                target_user_id=user_id,
                target_sprint_id=sprint_id,
                risk_score=risk_score,
                risk_factors=json.dumps(risk_factors),
                recommendations=json.dumps(recommendations),
                status='active'
            )
            db.session.add(alert)
            db.session.commit()
            
            logger.info(f"✅ Risk alert created for {user_id}: {risk_score:.0f}%")
            return notification.to_dict()
            
        except Exception as e:
            logger.error(f"❌ Error creating risk alert: {e}")
            db.session.rollback()
            return None
    
    @staticmethod
    def create_dependency_warning(user_id, source_story, dependent_story, risk_probability, cascade_impact):
        """Create a dependency warning notification"""
        try:
            # Determine severity
            if risk_probability >= 0.7:
                severity = 'critical'
                title = '🚨 Critical Dependency Risk'
            elif risk_probability >= 0.4:
                severity = 'high'
                title = '⚠️ High Dependency Risk'
            else:
                severity = 'medium'
                title = '⚡ Dependency Warning'
            
            message = f"Dependency between {source_story} → {dependent_story} has {risk_probability*100:.0f}% risk probability with cascade impact of {cascade_impact}."
            
            notification = Notification(
                user_id=user_id,
                notification_type='dependency_warning',
                severity=severity,
                title=title,
                message=message
            )
            db.session.add(notification)
            db.session.commit()
            
            logger.info(f"✅ Dependency warning created for {user_id}")
            return notification.to_dict()
            
        except Exception as e:
            logger.error(f"❌ Error creating dependency warning: {e}")
            db.session.rollback()
            return None
    
    @staticmethod
    def create_team_notification(team_id, title, message, severity='info'):
        """Create a notification for all team members"""
        try:
            # Get all team members
            team_members = User.query.filter_by(role='member').all()
            
            notifications = []
            for member in team_members:
                notification = Notification(
                    user_id=member.username,
                    notification_type='team_update',
                    severity=severity,
                    title=title,
                    message=message
                )
                db.session.add(notification)
                notifications.append(notification)
            
            db.session.commit()
            logger.info(f"✅ Team notification sent to {len(notifications)} members")
            return [n.to_dict() for n in notifications]
            
        except Exception as e:
            logger.error(f"❌ Error creating team notification: {e}")
            db.session.rollback()
            return []
    
    @staticmethod
    def get_user_notifications(user_id, unread_only=False):
        """Get notifications for a user"""
        try:
            query = Notification.query.filter_by(user_id=user_id)
            
            if unread_only:
                query = query.filter_by(is_read=False)
            
            notifications = query.order_by(Notification.created_at.desc()).limit(50).all()
            return [n.to_dict() for n in notifications]
            
        except Exception as e:
            logger.error(f"❌ Error getting notifications: {e}")
            return []
    
    @staticmethod
    def mark_as_read(notification_id, user_id):
        """Mark notification as read"""
        try:
            notification = Notification.query.filter_by(id=notification_id, user_id=user_id).first()
            
            if notification:
                notification.is_read = True
                notification.read_at = datetime.utcnow()
                db.session.commit()
                logger.info(f"✅ Notification {notification_id} marked as read")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Error marking notification as read: {e}")
            db.session.rollback()
            return False
    
    @staticmethod
    def dismiss_notification(notification_id, user_id):
        """Dismiss a notification"""
        try:
            notification = Notification.query.filter_by(id=notification_id, user_id=user_id).first()
            
            if notification:
                notification.is_dismissed = True
                db.session.commit()
                logger.info(f"✅ Notification {notification_id} dismissed")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Error dismissing notification: {e}")
            db.session.rollback()
            return False
    
    @staticmethod
    def acknowledge_alert(alert_id, user_id):
        """Acknowledge a risk alert"""
        try:
            alert = RiskAlert.query.get(alert_id)
            
            if alert:
                alert.status = 'acknowledged'
                alert.acknowledged_by = user_id
                alert.acknowledged_at = datetime.utcnow()
                db.session.commit()
                logger.info(f"✅ Alert {alert_id} acknowledged by {user_id}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"❌ Error acknowledging alert: {e}")
            db.session.rollback()
            return False
    
    @staticmethod
    def get_active_alerts(user_id=None, severity=None):
        """Get active risk alerts"""
        try:
            query = RiskAlert.query.filter_by(status='active')
            
            if user_id:
                query = query.filter_by(target_user_id=user_id)
            
            if severity:
                query = query.filter_by(severity=severity)
            
            alerts = query.order_by(RiskAlert.created_at.desc()).all()
            return [a.to_dict() for a in alerts]
            
        except Exception as e:
            logger.error(f"❌ Error getting active alerts: {e}")
            return []


class AutoAlertService:
    """Automatic alert generation based on AI predictions"""
    
    @staticmethod
    def analyze_sprint_health_and_alert(predictions):
        """Analyze sprint health predictions and create alerts"""
        try:
            alerts_created = 0
            
            for prediction in predictions:
                user_id = prediction.get('user_id')
                risk_score = prediction.get('predicted_risk_score', 0)
                
                # Create alert if risk is above threshold (50%)
                if risk_score >= 50:
                    risk_factors = {
                        'high_meetings': prediction.get('meeting_hours', 0) > 5,
                        'low_focus_time': prediction.get('focus_hours', 0) < 2,
                        'high_calendar_density': prediction.get('calendar_density', 0) > 0.8
                    }
                    
                    recommendations = prediction.get('recommendations', [])
                    
                    NotificationService.create_risk_alert(
                        user_id=user_id,
                        risk_score=risk_score,
                        risk_factors=risk_factors,
                        recommendations=recommendations
                    )
                    alerts_created += 1
            
            logger.info(f"✅ Auto-generated {alerts_created} risk alerts")
            return alerts_created
            
        except Exception as e:
            logger.error(f"❌ Error in auto-alert generation: {e}")
            return 0
    
    @staticmethod
    def analyze_dependencies_and_alert(dependencies):
        """Analyze dependencies and create warnings"""
        try:
            warnings_created = 0
            
            for dep in dependencies:
                risk_prob = dep.get('predicted_risk_probability', 0)
                
                # Create warning if risk is high (>60%)
                if risk_prob >= 0.6:
                    # Get affected users (would need actual user assignment data)
                    user_id = dep.get('assigned_user', 'manager')
                    
                    NotificationService.create_dependency_warning(
                        user_id=user_id,
                        source_story=dep.get('source_story'),
                        dependent_story=dep.get('dependent_story'),
                        risk_probability=risk_prob,
                        cascade_impact=dep.get('predicted_cascade_impact', 0)
                    )
                    warnings_created += 1
            
            logger.info(f"✅ Auto-generated {warnings_created} dependency warnings")
            return warnings_created
            
        except Exception as e:
            logger.error(f"❌ Error in dependency warning generation: {e}")
            return 0