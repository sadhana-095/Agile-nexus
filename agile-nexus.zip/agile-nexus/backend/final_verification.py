"""
Final verification - Show what's really in the database
"""
from app import create_app
from models import CalendarData, CodeActivity, CommunicationData

app = create_app()

with app.app_context():
    print("\n" + "="*70)
    print("FINAL DATA VERIFICATION")
    print("="*70)
    
    # GitHub Users
    github_users = ['Rooba8925', 'praneetaAD078', 'sadhana-095']
    
    print("\n📊 SUMMARY:")
    print(f"   Calendar Events: {CalendarData.query.filter_by(data_source='real').count()} real + {CalendarData.query.filter_by(data_source='mock').count()} mock = {CalendarData.query.count()} total")
    print(f"   Slack Records: {CommunicationData.query.filter_by(data_source='real').count()} real + {CommunicationData.query.filter_by(data_source='mock').count()} mock = {CommunicationData.query.count()} total")
    print(f"   GitHub Repos: {CodeActivity.query.filter_by(data_source='real').count()} real + {CodeActivity.query.filter_by(data_source='mock').count()} mock = {CodeActivity.query.count()} total")
    
    print("\n💻 GITHUB DETAILED BREAKDOWN:")
    print("="*70)
    
    total_real_repos = 0
    for username in github_users:
        repos = CodeActivity.query.filter_by(
            user_id=username,
            data_source='real'
        ).all()
        
        total_real_repos += len(repos)
        
        print(f"\n👤 {username}:")
        print(f"   Unique Repositories: {len(repos)}")
        
        if len(repos) > 0:
            total_commits = sum(r.commits_count for r in repos)
            total_lines = sum(r.lines_added for r in repos)
            print(f"   Total Commits: {total_commits}")
            print(f"   Total Lines: +{total_lines}")
            print(f"   Repositories:")
            
            for i, repo in enumerate(repos, 1):
                print(f"      {i}. {repo.repository}")
                print(f"         Commits: {repo.commits_count}, Lines: +{repo.lines_added}")
        else:
            print(f"   ⚠️ No repositories found")
    
    print("\n" + "="*70)
    print(f"✅ TOTAL UNIQUE REAL REPOS: {total_real_repos}")
    print("="*70)